/* Kupika Safi — page logic (English / Kiswahili). Depends on window.CC (data) and window.Viz (charts). */
(function () {
  "use strict";
  const D = window.CC, V = D.views, M = D.meta, Z = window.Viz;
  const { el, s, $, clear, css, pct, nf0, tzs, tzsShort, hbar, stacked, legend, table, cell, bindTip, textW, niceScale } = Z;

  // ------------------------------------------------------------------ language
  let LANG = "en";
  try { const l = localStorage.getItem("ks-lang"); if (l === "sw" || l === "en") LANG = l; } catch (e) { /* storage unavailable */ }
  const L = (en, sw) => (LANG === "sw" ? sw : en);
  window.L = L;
  const SW = {
    // fuels
    Firewood: "Kuni", Charcoal: "Mkaa", LPG: "Gesi (LPG)", Electricity: "Umeme", Biogas: "Biogesi", "Natural gas": "Gesi asilia", Bioethanol: "Bioethanoli",
    "Kerosene / paraffin": "Mafuta ya taa", "Crop residues & other": "Mabaki ya mazao na mengine", "None reported": "Hakuna",
    "Electricity & other clean": "Umeme na nishati safi nyingine", "Kerosene & other": "Mafuta ya taa na mengine",
    // stoves
    "Three-stone fire": "Mafiga matatu", "Round mud stove": "Jiko la udongo la duara", "Improved cookstove": "Jiko banifu", "Rocket stove": "Jiko la roketi",
    "Burned mud/clay stove": "Jiko la udongo uliochomwa", "Lorena rocket stove": "Jiko la roketi la Lorena", "Metal rocket stove": "Jiko la roketi la chuma",
    "Mozambique metal rocket stove": "Jiko la roketi la chuma (Msumbiji)", "Traditional charcoal stove": "Jiko la mkaa la kawaida",
    "Traditional raised charcoal stove": "Jiko la mkaa la kawaida lenye miguu", "Old-generation charcoal ICS": "Jiko banifu la mkaa (la zamani)",
    "Ceramic-lined charcoal ICS": "Jiko banifu la mkaa lenye kauri",
    // groups
    "No electricity": "Hakuna umeme", "Solar or other off-grid": "Sola au umeme usio wa gridi", "Grid (TANESCO)": "Gridi (TANESCO)",
    "None / pre-primary": "Hakuna / elimu ya awali", Primary: "Msingi", Secondary: "Sekondari", Tertiary: "Elimu ya juu",
    Agriculture: "Kilimo", "Not working": "Hafanyi kazi", "Business / self-employed": "Biashara / kujiajiri", "Formal employment": "Ajira rasmi",
    "Female-headed": "Mkuu wa kaya mwanamke", "Male-headed": "Mkuu wa kaya mwanaume",
    "1–2 people": "Watu 1–2", "3–4 people": "Watu 3–4", "5–6 people": "Watu 5–6", "7+ people": "Watu 7 au zaidi",
    Rural: "Vijijini", Urban: "Mijini", "Not on grid": "bila gridi", "On grid": "na gridi",
    // model terms
    "Grid connection (TANESCO)": "Kuunganishwa na gridi (TANESCO)", "Off-grid electricity only": "Umeme usio wa gridi pekee", "Urban residence": "Kuishi mjini",
    "Head education: Primary": "Elimu ya mkuu wa kaya: msingi", "Head education: Secondary": "Elimu ya mkuu wa kaya: sekondari",
    "Head education: Tertiary": "Elimu ya mkuu wa kaya: elimu ya juu", "Head occupation: Agriculture": "Shughuli ya mkuu wa kaya: kilimo",
    "Head occupation: Business / self-employed": "Shughuli ya mkuu wa kaya: biashara / kujiajiri", "Head occupation: Not working": "Mkuu wa kaya hafanyi kazi",
    "Male-headed household": "Mkuu wa kaya ni mwanaume", "Age of head (per year)": "Umri wa mkuu wa kaya (kila mwaka)", "Household size (per person)": "Ukubwa wa kaya (kila mtu)",
  };
  const tr = (x) => (LANG === "sw" && SW[x] ? SW[x] : x);
  function applyStatic() {
    document.documentElement.lang = LANG;
    document.querySelectorAll("[data-sw]").forEach((n) => {
      if (n.dataset.en == null) n.dataset.en = n.innerHTML;
      n.innerHTML = LANG === "sw" ? n.dataset.sw : n.dataset.en;
    });
    document.title = L("Kupika Safi — Tanzania Clean Cooking Observatory", "Kupika Safi — Kituo cha Takwimu za Nishati Safi ya Kupikia Tanzania");
    document.querySelectorAll("[data-lang]").forEach((b) => b.setAttribute("aria-pressed", String(b.dataset.lang === LANG)));
  }

  const state = { focus: "national", dim: "region", fuelsMetric: "primary_clean", stovesMetric: "ch_improved", costMetric: "lpg_refill_6", drvOutcome: "primary_clean", progArea: "national" };

  // ------------------------------------------------------------------ keys & labels
  const AREA_KEYS = ["area_rural", "area_urban"];
  const REGION_KEYS = Object.keys(V).filter((k) => k.startsWith("reg_")).sort((a, b) => V[a].label.localeCompare(V[b].label));
  const DIMS = {
    area: { label: () => L("Rural / urban", "Vijijini / mijini"), keys: AREA_KEYS, noun: () => L("area", "eneo") },
    region: { label: () => L("Region", "Mkoa"), keys: REGION_KEYS, noun: () => L("region", "mkoa") },
  };
  const label = (k) => (k === "national" ? L("Mainland Tanzania", "Tanzania Bara") : tr(V[k].label));
  const focusName = () => label(state.focus);
  const isNat = () => state.focus === "national";
  const GROUPS = [
    { name: "Firewood", keys: ["Firewood"], slot: "--s1", ink: "light" },
    { name: "Charcoal", keys: ["Charcoal"], slot: "--s2", ink: "light" },
    { name: "LPG", keys: ["LPG"], slot: "--s3", ink: "light" },
    { name: "Electricity & other clean", keys: ["Electricity", "Biogas", "Natural gas", "Bioethanol"], slot: "--s4", ink: "dark" },
    { name: "Kerosene & other", keys: ["Kerosene / paraffin", "Crop residues & other", "None reported"], slot: "--s5", ink: "light" },
  ];
  const groupSeries = () => GROUPS.map((g) => ({ name: tr(g.name), color: css(g.slot), ink: g.ink }));
  const groupParts = (obj) => GROUPS.map((g) => g.keys.reduce((a, k) => a + (obj[k] || 0), 0));
  const isDark = () => document.documentElement.dataset.theme === "dark" || (!document.documentElement.dataset.theme && matchMedia("(prefers-color-scheme: dark)").matches);
  const ordinal3 = () => (isDark() ? ["#184f95", "#3987e5", "#9ec5f4"] : ["#86b6ef", "#2a78d6", "#104281"]);
  const CLEAN = () => css("--s3");
  const POLL = () => css("--s2");
  const ppU = () => L("pp", "pointi");
  const pp = (x, d = 1) => (x == null ? "–" : (x >= 0 ? "+" : "−") + Math.abs(x * 100).toFixed(d) + " " + ppU());
  const P1 = (x) => pct(x, 1), PA = (x) => pct(x);
  const mainland = () => L("Mainland", "Tanzania Bara");

  // ------------------------------------------------------------------ shared UI
  function seg(host, options, current, onPick) {
    clear(host);
    options.forEach((o) => host.append(el("button", { type: "button", "aria-pressed": String(o.id === current), text: typeof o.name === "function" ? o.name() : o.name, onclick: () => onPick(o.id) })));
  }
  function focusSelect() {
    const sel = el("select", { "aria-label": L("Focus on", "Angalia") });
    sel.append(el("option", { value: "national", text: label("national") }));
    const g1 = el("optgroup", { label: L("Area", "Eneo") }); AREA_KEYS.forEach((k) => g1.append(el("option", { value: k, text: label(k) }))); sel.append(g1);
    const g2 = el("optgroup", { label: L("Region", "Mkoa") }); REGION_KEYS.forEach((k) => g2.append(el("option", { value: k, text: label(k) }))); sel.append(g2);
    sel.value = state.focus;
    sel.addEventListener("change", () => { state.focus = sel.value; renderAll(); });
    return sel;
  }
  function buildFilters(page) {
    const host = document.querySelector(`[data-filters="${page}"]`);
    if (!host) return;
    clear(host);
    if (page === "drivers") {
      const sg = el("div", { class: "seg" });
      seg(sg, [{ id: "primary_clean", name: L("Clean main fuel", "Nishati kuu ni safi") }, { id: "any_clean", name: L("Uses any clean fuel", "Inatumia nishati safi yoyote") }], state.drvOutcome, (id) => { state.drvOutcome = id; renderAll(); });
      host.append(el("label", null, L("Outcome", "Matokeo"), sg));
      return;
    }
    host.append(el("label", null, L("Focus on", "Angalia"), focusSelect()));
    const sg = el("div", { class: "seg" });
    seg(sg, Object.entries(DIMS).map(([id, d]) => ({ id, name: d.label })), state.dim, (id) => { state.dim = id; renderAll(); });
    host.append(el("label", null, L("Compare by", "Linganisha kwa"), sg));
  }
  function tiles(id, items) {
    const host = clear($(id));
    items.forEach((t) => host.append(el("div", { class: "tile" + (t.clean ? " clean" : "") }, el("div", { class: "label", text: t.label }), el("div", { class: "value", text: t.value }), el("div", { class: "sub", text: t.sub || "" }))));
  }
  const natSub = (get, fmt) => (isNat() ? null : mainland() + ": " + fmt(get(V.national)));
  const dimKeys = () => DIMS[state.dim].keys;
  const withNat = (keys) => ["national"].concat(keys);
  const sortDesc = (keys, f) => (state.dim === "region" ? keys.slice().sort((a, b) => (f(V[b]) ?? -1) - (f(V[a]) ?? -1)) : keys);
  const rowH = () => (state.dim === "region" ? 24 : 30);
  const sortedNote = () => (state.dim === "region" ? L(" · sorted high to low", " · kutoka juu hadi chini") : "");
  const tickNote = () => (isNat() ? "" : L(" · black tick = Mainland", " · alama nyeusi = Tanzania Bara"));
  const compareTitle = () => L("Compare by ", "Linganisha kwa ") + DIMS[state.dim].noun();

  function compare(id, m, color) {
    const keys = sortDesc(dimKeys(), m.get);
    hbar($(id), keys.map((k) => ({ label: label(k), value: m.get(V[k]), highlight: k === state.focus, color,
      tip: { title: label(k), rows: [{ color, value: m.fmt(m.get(V[k])), label: m.name() }], sub: (m.n ? L("Reporting households: ", "Kaya zilizotoa taarifa: ") + nf0.format(m.n(V[k])) : L("Sample: ", "Sampuli: ") + nf0.format(V[k].n) + L(" households", " kaya")) } })),
    { fmt: m.fmt, axisFmt: m.axis || m.fmt, cap: m.cap, max: m.max, ref: m.get(V.national), refLabel: mainland(), rowH: rowH() });
  }

  function forest(container, rows, opt) {
    const o = Object.assign({ rowH: 28 }, opt);
    clear(container);
    const width = Math.max(340, container.clientWidth || 700);
    const labelW = Math.min(280, Math.max(120, ...rows.map((r) => textW(r.label, 12) + 14)));
    const valW = 84;
    const plotW = width - labelW - valW;
    const lo = Math.min(0, ...rows.map((r) => r.ame - 1.96 * r.se));
    const hi = Math.max(0, ...rows.map((r) => r.ame + 1.96 * r.se));
    const ext = niceScale(Math.max(Math.abs(lo), Math.abs(hi)), 1).max;
    const min = lo < 0 ? -ext : 0, max = hi > 0 ? ext : 0;
    const X = (v) => labelW + ((v - min) / (max - min)) * plotW;
    const H = rows.length * o.rowH + 24;
    const svg = s("svg", { viewBox: `0 0 ${width} ${H}`, role: "img", "aria-label": o.aria || "" });
    for (let i = 0; i <= 4; i++) {
      const v = min + ((max - min) * i) / 4;
      svg.append(s("line", { x1: X(v), x2: X(v), y1: 0, y2: H - 18, stroke: Math.abs(v) < 1e-9 ? css("--baseline") : css("--grid") }));
      svg.append(s("text", { x: X(v), y: H - 4, "text-anchor": "middle", "font-size": 11, fill: css("--axis-muted"), text: (v > 0 ? "+" : v < 0 ? "−" : "") + Math.abs(v * 100).toFixed(0) + " " + ppU() }));
    }
    const pos = css("--s1"), neg = css("--s8");
    rows.forEach((r, i) => {
      const y = i * o.rowH, bh = 12, by = y + (o.rowH - bh) / 2;
      const g = s("g");
      const sig = r.p != null && r.p < 0.05;
      g.append(s("text", { x: labelW - 10, y: y + o.rowH / 2 + 4, "text-anchor": "end", "font-size": 12, fill: css("--text-primary"), "font-weight": sig ? 600 : 400, text: r.label }));
      const x0 = X(0), x1 = X(r.ame);
      g.append(s("rect", { x: Math.min(x0, x1), y: by, width: Math.max(1, Math.abs(x1 - x0)), height: bh, rx: 3, fill: r.ame >= 0 ? pos : neg, opacity: sig ? 1 : 0.35 }));
      const cl = X(r.ame - 1.96 * r.se), cr = X(r.ame + 1.96 * r.se), cy = y + o.rowH / 2;
      [[cl, cr, cy, cy], [cl, cl, cy - 4, cy + 4], [cr, cr, cy - 4, cy + 4]].forEach(([a1, a2, b1, b2]) => g.append(s("line", { x1: a1, x2: a2, y1: b1, y2: b2, stroke: css("--text-primary"), "stroke-width": 1.5 })));
      g.append(s("text", { x: width - 4, y: cy + 4, "text-anchor": "end", "font-size": 12, fill: css("--text-secondary"), "font-weight": sig ? 600 : 400, text: pp(r.ame) }));
      g.append(s("rect", { x: 0, y, width, height: o.rowH, fill: "transparent" }));
      bindTip(g, () => ({ title: r.label, rows: [{ color: r.ame >= 0 ? pos : neg, value: pp(r.ame), label: L("average marginal effect", "athari ya wastani") }],
        sub: L("95% CI ", "Uhakika 95%: ") + pp(r.ame - 1.96 * r.se) + L(" to ", " hadi ") + pp(r.ame + 1.96 * r.se) + " · " + (r.p < 0.001 ? "p < 0.001" : "p = " + r.p.toFixed(3)) + (sig ? "" : L(" · not statistically significant", " · haina umuhimu wa kitakwimu")) }));
      svg.append(g);
    });
    container.append(svg);
  }

  // ------------------------------------------------------------------ OVERVIEW
  function trendPoints() {
    const cleanOf = (o) => ["LPG", "Electricity", "Biogas", "Natural gas", "Bioethanol"].reduce((a, k) => a + ((o && o[k]) || 0), 0);
    return [
      { year: 2018.0, label: "HBS 2017-18", v: cleanOf(D.trend["HBS 2017-18"].national) },
      { year: 2022.0, label: "IASES 2021/22", v: cleanOf(D.trend["IASES 2021-22"].national) },
      { year: 2023.5, label: "HECS 2023", v: cleanOf(D.trend["HECS 2023"].national) },
    ];
  }
  function pace() {
    const pts = trendPoints();
    const n = pts.length, mx = pts.reduce((a, p) => a + p.year, 0) / n, my = pts.reduce((a, p) => a + p.v, 0) / n;
    const slope = pts.reduce((a, p) => a + (p.year - mx) * (p.v - my), 0) / pts.reduce((a, p) => a + (p.year - mx) ** 2, 0);
    const last = pts[n - 1];
    return { pts, slope, needed: (0.8 - last.v) / (2034.5 - last.year), proj2034: last.v + slope * (2034.5 - last.year), last };
  }
  const ppyr = (x) => (x * 100).toFixed(1) + L(" pp/yr", " pointi/mwaka");
  function renderHome() {
    const n = V.national, p = pace();
    const t = clear($("hero-target"));
    const bar = el("div", { class: "target-bar" });
    bar.append(el("div", { class: "fill2", style: `width:${n.primary_clean_or_ics * 100}%` }), el("div", { class: "fill", style: `width:${n.primary_clean * 100}%` }), el("div", { class: "goal", style: "left:80%" }));
    t.append(bar, el("div", { class: "target-legend" },
      el("span", null, el("b", { text: pct(n.primary_clean) }), document.createTextNode(L(" cook mainly with clean fuels (2023)", " wanapika hasa kwa nishati safi (2023)"))),
      el("span", null, el("b", { text: pct(n.primary_clean_or_ics) }), document.createTextNode(L(" counting improved stoves", " ukihesabu majiko banifu"))),
      el("span", null, el("b", { text: "80%" }), document.createTextNode(L(" target by 2034", " lengo ifikapo 2034")))));
    const k = clear($("kpis"));
    [[pct(n.use.Firewood), L("of households cook with firewood", "ya kaya zinapikia kwa kuni")], [pct(n.three_stone), L("use a three-stone fire", "zinatumia mafiga matatu")],
      [pct(n.indoor), L("cook mainly indoors", "zinapikia hasa ndani ya nyumba")], [pct(n.grid), L("have a TANESCO grid connection", "zimeunganishwa na gridi ya TANESCO")]]
      .forEach(([v, l]) => k.append(el("div", { class: "kpi" }, el("div", { class: "v", text: v }), el("div", { class: "l", text: l }))));
    const regs = REGION_KEYS.map((x) => V[x]).sort((a, b) => b.primary_clean - a.primary_clean);
    const educ = D.drivers.educ, top = regs[0], bot = regs[regs.length - 1], below5 = regs.filter((r) => r.primary_clean < 0.05).length;
    const f = [
      { tag: L("Clean cooking", "Nishati safi"), big: pct(n.primary_clean),
        text: L(`of households cook mainly with clean fuels, mostly LPG. The share is ${pct(V.area_urban.primary_clean)} in urban areas but only ${pct(V.area_rural.primary_clean)} in rural areas.`,
          `ya kaya zinapika hasa kwa nishati safi, zaidi gesi (LPG). Mijini ni ${pct(V.area_urban.primary_clean)}, lakini vijijini ni ${pct(V.area_rural.primary_clean)} tu.`), link: "#fuels" },
      { tag: L("Fuel stacking", "Kuchanganya nishati"), big: pct(n.stacking / n.any_clean),
        text: L(`of households that use a clean fuel still also burn firewood, charcoal or kerosene. Only ${pct(n.exclusive_clean, 1)} of all households cook with clean fuels alone.`,
          `ya kaya zinazotumia nishati safi bado zinatumia pia kuni, mkaa au mafuta ya taa. Ni ${pct(n.exclusive_clean, 1)} tu ya kaya zote zinazopika kwa nishati safi pekee.`), link: "#fuels" },
      { tag: L("Regional gap", "Tofauti za mikoa"), big: pct(top.primary_clean) + L(" vs ", " dhidi ya ") + pct(bot.primary_clean, 1),
        text: L(`Clean main fuel in ${top.label} compared with ${bot.label}. ${below5} of 26 regions are below 5%.`,
          `Nishati kuu safi ${top.label} ikilinganishwa na ${bot.label}. Mikoa ${below5} kati ya 26 iko chini ya 5%.`), link: "#fuels" },
      { tag: L("Grid paradox", "Kitendawili cha gridi"), big: pct(n.use.Electricity, 1),
        text: L(`of households cook with electricity at all, although ${pct(n.grid)} are connected to the TANESCO grid.`,
          `ya kaya ndizo zinapika kwa umeme, ingawa ${pct(n.grid)} zimeunganishwa na gridi ya TANESCO.`), link: "#drivers" },
      { tag: L("Improved stoves", "Majiko banifu"), big: pct(n.ch_improved),
        text: L(`of charcoal users have an improved charcoal stove, but only ${pct(n.fw_improved, 1)} of firewood users have an improved firewood stove.`,
          `ya watumiaji wa mkaa wana jiko banifu la mkaa, lakini ni ${pct(n.fw_improved, 1)} tu ya watumiaji wa kuni wenye jiko banifu la kuni.`), link: "#stoves" },
      { tag: L("Cost", "Gharama"), big: tzs(n.cost.lpg_month),
        text: L(`median monthly LPG spending among buyers, against ${tzs(n.cost.ch_month)} for charcoal. A 6 kg refill costs about ${tzs(n.cost.lpg_refill_6)}.`,
          `ni matumizi ya kati ya gesi kwa mwezi kwa wanaonunua, ukilinganisha na ${tzs(n.cost.ch_month)} kwa mkaa. Kujaza mtungi wa kilo 6 ni takriban ${tzs(n.cost.lpg_refill_6)}.`), link: "#cost" },
      { tag: L("Education", "Elimu"), big: pct(educ[educ.length - 1].primary_clean),
        text: L(`of households headed by someone with tertiary education cook mainly with clean fuels, against ${pct(educ[0].primary_clean, 1)} where the head had no schooling.`,
          `ya kaya ambazo mkuu wake ana elimu ya juu zinapika hasa kwa nishati safi, ukilinganisha na ${pct(educ[0].primary_clean, 1)} pale mkuu wa kaya hakusoma.`), link: "#drivers" },
      { tag: L("Pace", "Kasi"), big: ppyr(p.slope),
        text: L(`is the observed rise in clean cooking since 2017-18. Reaching 80% by 2034 needs about ${(p.needed * 100).toFixed(1)} percentage points a year.`,
          `ndiyo kasi ya ongezeko la nishati safi tangu 2017-18. Kufikia 80% ifikapo 2034 kunahitaji takriban pointi ${(p.needed * 100).toFixed(1)} za asilimia kila mwaka.`), link: "#progress" },
    ];
    const host = clear($("findings"));
    f.forEach((x) => host.append(el("a", { class: "card", href: x.link }, el("span", { class: "tag", text: x.tag }), el("div", { class: "big", text: x.big }), el("p", { text: x.text }), el("span", { class: "go", text: L("Explore →", "Angalia zaidi →") }))));
  }

  // ------------------------------------------------------------------ FUELS
  const FUEL_METRICS = [
    { id: "primary_clean", name: () => L("Clean main fuel", "Nishati kuu safi"), get: (v) => v.primary_clean },
    { id: "any_clean", name: () => L("Any clean fuel", "Nishati safi yoyote"), get: (v) => v.any_clean },
    { id: "exclusive_clean", name: () => L("Clean only", "Safi pekee"), get: (v) => v.exclusive_clean },
    { id: "stacking", name: () => L("Stacking", "Kuchanganya"), get: (v) => v.stacking },
    { id: "lpg", name: () => L("Uses LPG", "Inatumia gesi"), get: (v) => v.use.LPG },
    { id: "firewood", name: () => L("Uses firewood", "Inatumia kuni"), get: (v) => v.use.Firewood },
    { id: "charcoal", name: () => L("Uses charcoal", "Inatumia mkaa"), get: (v) => v.use.Charcoal },
    { id: "indoor", name: () => L("Cooks indoors", "Inapikia ndani"), get: (v) => v.indoor },
    { id: "events", name: () => L("Clean share of sessions", "Sehemu ya mapishi kwa nishati safi"), get: (v) => v.events_clean_share },
  ].map((m) => Object.assign({ fmt: P1, axis: PA, cap: 1 }, m));
  function renderFuels() {
    const f = V[state.focus], nat = V.national;
    tiles("fuels-tiles", [
      { label: L("Main cooking fuel is clean", "Nishati kuu ya kupikia ni safi"), value: P1(f.primary_clean), sub: natSub((v) => v.primary_clean, P1) || L("LPG, electricity, biogas, ethanol", "Gesi, umeme, biogesi, ethanoli"), clean: true },
      { label: L("Use any clean fuel", "Zinatumia nishati safi yoyote"), value: P1(f.any_clean), sub: natSub((v) => v.any_clean, P1) || L("even occasionally", "hata mara chache"), clean: true },
      { label: L("Cook with firewood", "Zinapikia kwa kuni"), value: P1(f.use.Firewood), sub: natSub((v) => v.use.Firewood, P1) || L("of households", "ya kaya") },
      { label: L("Cook mainly indoors", "Zinapikia hasa ndani"), value: P1(f.indoor), sub: natSub((v) => v.indoor, P1) || L("exposure to smoke", "hatari ya moshi") },
    ]);
    $("fuels-a-desc").textContent = focusName() + L(" · share of households", " · asilimia ya kaya") + tickNote();
    const fuels = M.fuels.filter((k) => (nat.use[k] || 0) > 0.0004 || (f.use[k] || 0) > 0.0004);
    const isClean = (k) => M.clean_fuels.includes(k);
    hbar($("fuels-a"), fuels.map((k) => ({ label: tr(k), value: f.use[k], ref: isNat() ? null : nat.use[k], color: isClean(k) ? CLEAN() : POLL(),
      tip: { title: tr(k), rows: [{ color: isClean(k) ? CLEAN() : POLL(), value: P1(f.use[k]), label: L("of households use it", "ya kaya zinaitumia") }],
        sub: isNat() ? (isClean(k) ? L("Clean fuel", "Nishati safi") : L("Polluting fuel", "Nishati chafu")) : mainland() + ": " + P1(nat.use[k]) } })),
    { fmt: P1, axisFmt: PA, cap: 1, rowH: 28 });

    const o3 = ordinal3();
    const s3 = [{ name: L("No clean fuel", "Hakuna nishati safi"), color: o3[0], ink: "dark" }, { name: L("Clean + polluting (stacking)", "Safi + chafu (kuchanganya)"), color: o3[1] }, { name: L("Clean fuels only", "Nishati safi pekee"), color: o3[2] }];
    legend($("fuels-b-legend"), s3);
    $("fuels-b-desc").textContent = L("Share of households, by ", "Asilimia ya kaya, kwa ") + DIMS[state.dim].noun();
    stacked($("fuels-b"), withNat(dimKeys()).map((k) => ({ label: label(k), highlight: k === state.focus, parts: [V[k].solid_only, V[k].stacking, V[k].exclusive_clean] })), s3, { rowH: state.dim === "region" ? 22 : 30 });

    const gs = groupSeries();
    legend($("fuels-c-legend"), gs);
    $("fuels-c-desc").textContent = L("Share of households by main fuel (most cooking sessions per week), by ", "Asilimia ya kaya kwa nishati kuu (inayotumika mara nyingi zaidi kwa wiki), kwa ") + DIMS[state.dim].noun();
    stacked($("fuels-c"), withNat(sortDesc(dimKeys(), (v) => v.primary_clean)).map((k) => ({ label: label(k), highlight: k === state.focus, parts: groupParts(V[k].primary) })), gs,
      { rowH: state.dim === "region" ? 22 : 30, partFmt: (v, r) => L("Main fuel for ", "Nishati kuu kwa ") + P1(v) + L(" of households in ", " ya kaya, ") + r.label });

    const m = FUEL_METRICS.find((x) => x.id === state.fuelsMetric);
    seg($("fuels-d-metric"), FUEL_METRICS, m.id, (id) => { state.fuelsMetric = id; renderFuels(); });
    $("fuels-d-title").textContent = compareTitle();
    $("fuels-d-desc").textContent = m.name() + L(" · share of households", " · asilimia ya kaya") + sortedNote();
    compare("fuels-d", m, ["firewood", "charcoal", "indoor"].includes(m.id) ? POLL() : CLEAN());

    const heads = [DIMS[state.dim].label(), L("Households (n)", "Kaya (idadi)"), L("Clean main fuel", "Nishati kuu safi"), L("Any clean fuel", "Nishati safi yoyote"), L("Clean only", "Safi pekee"), L("Stacking", "Kuchanganya"), L("No clean fuel", "Hakuna nishati safi"), L("Cooks indoors", "Inapikia ndani")]
      .concat(M.fuels.map((k) => L("Uses ", "Inatumia: ") + tr(k))).concat(GROUPS.map((g) => L("Main: ", "Kuu: ") + tr(g.name)));
    table("fuels-table", heads, withNat(dimKeys()).map((k) => {
      const v = V[k];
      return [cell(label(k)), cell(v.n, nf0.format(v.n))].concat([v.primary_clean, v.any_clean, v.exclusive_clean, v.stacking, v.solid_only, v.indoor].map((x) => cell(x, P1(x))))
        .concat(M.fuels.map((f2) => cell(v.use[f2], P1(v.use[f2])))).concat(groupParts(v.primary).map((x) => cell(x, P1(x))));
    }), withNat(dimKeys()).indexOf(state.focus));
  }

  // ------------------------------------------------------------------ STOVES
  const STOVE_METRICS = [
    { id: "ch_improved", name: () => L("Improved charcoal stove", "Jiko banifu la mkaa"), get: (v) => v.ch_improved },
    { id: "fw_improved", name: () => L("Improved firewood stove", "Jiko banifu la kuni"), get: (v) => v.fw_improved },
    { id: "three_stone", name: () => L("Three-stone fire", "Mafiga matatu"), get: (v) => v.three_stone },
    { id: "ics", name: () => L("Clean or improved main fuel", "Nishati kuu safi au jiko banifu"), get: (v) => v.primary_clean_or_ics },
  ].map((m) => Object.assign({ fmt: P1, axis: PA, cap: 1 }, m));
  function renderStoves() {
    const f = V[state.focus], nat = V.national;
    tiles("stoves-tiles", [
      { label: L("Use a three-stone fire", "Zinatumia mafiga matatu"), value: P1(f.three_stone), sub: natSub((v) => v.three_stone, P1) || L("of all households", "ya kaya zote") },
      { label: L("Charcoal users with an improved stove", "Watumiaji wa mkaa wenye jiko banifu"), value: P1(f.ch_improved), sub: natSub((v) => v.ch_improved, P1) || L("old-generation or ceramic-lined ICS", "jiko banifu la zamani au lenye kauri"), clean: true },
      { label: L("Firewood users with an improved stove", "Watumiaji wa kuni wenye jiko banifu"), value: P1(f.fw_improved), sub: natSub((v) => v.fw_improved, P1) || L("ICS or rocket stove", "jiko banifu au la roketi"), clean: true },
      { label: L("Clean or improved main fuel", "Nishati kuu safi au jiko banifu"), value: P1(f.primary_clean_or_ics), sub: natSub((v) => v.primary_clean_or_ics, P1) || L("closer to the strategy's definition", "karibu na ufafanuzi wa mkakati"), clean: true },
    ]);
    const improvedFw = ["Improved cookstove", "Rocket stove", "Lorena rocket stove", "Metal rocket stove", "Mozambique metal rocket stove"];
    const improvedCh = ["Old-generation charcoal ICS", "Ceramic-lined charcoal ICS"];
    const stoveRows = (obj, natObj, improved) => Object.keys(obj).filter((k) => (natObj[k] || 0) > 0 || (obj[k] || 0) > 0).map((k) => {
      const col = improved.includes(k) ? CLEAN() : POLL();
      return { label: tr(k), value: obj[k], ref: isNat() ? null : natObj[k], color: col,
        tip: { title: tr(k), rows: [{ color: col, value: P1(obj[k]), label: improved.includes(k) ? L("improved stove", "jiko banifu") : L("traditional stove", "jiko la kawaida") }], sub: isNat() ? null : mainland() + ": " + P1(natObj[k]) } };
    }).sort((a, b) => (b.value || 0) - (a.value || 0));
    const teal = L(" · green = improved", " · kijani = jiko banifu");
    $("stoves-a-desc").textContent = focusName() + L(" · share of households that cook with firewood", " · asilimia ya kaya zinazopikia kwa kuni") + teal;
    hbar($("stoves-a"), stoveRows(f.fw_stoves, nat.fw_stoves, improvedFw), { fmt: P1, axisFmt: PA, cap: 1, rowH: 26 });
    $("stoves-b-desc").textContent = focusName() + L(" · share of households that cook with charcoal", " · asilimia ya kaya zinazopikia kwa mkaa") + teal;
    hbar($("stoves-b"), stoveRows(f.ch_stoves, nat.ch_stoves, improvedCh), { fmt: P1, axisFmt: PA, cap: 1, rowH: 30 });
    const m = STOVE_METRICS.find((x) => x.id === state.stovesMetric);
    seg($("stoves-c-metric"), STOVE_METRICS, m.id, (id) => { state.stovesMetric = id; renderStoves(); });
    $("stoves-c-title").textContent = compareTitle();
    $("stoves-c-desc").textContent = m.name() + sortedNote();
    compare("stoves-c", m, m.id === "three_stone" ? POLL() : CLEAN());
    const fwK = Object.keys(nat.fw_stoves), chK = Object.keys(nat.ch_stoves);
    table("stoves-table", [DIMS[state.dim].label(), L("Households (n)", "Kaya (idadi)"), L("Three-stone fire (all households)", "Mafiga matatu (kaya zote)"), L("Improved charcoal stove (charcoal users)", "Jiko banifu la mkaa (watumiaji wa mkaa)"), L("Improved firewood stove (firewood users)", "Jiko banifu la kuni (watumiaji wa kuni)"), L("Clean or improved main fuel", "Nishati kuu safi au jiko banifu")]
      .concat(fwK.map((k) => tr(k) + L(" (firewood users)", " (watumiaji wa kuni)"))).concat(chK.map((k) => tr(k) + L(" (charcoal users)", " (watumiaji wa mkaa)"))),
    withNat(dimKeys()).map((k) => { const v = V[k]; return [cell(label(k)), cell(v.n, nf0.format(v.n))].concat([v.three_stone, v.ch_improved, v.fw_improved, v.primary_clean_or_ics].map((x) => cell(x, P1(x)))).concat(fwK.map((kk) => cell(v.fw_stoves[kk], P1(v.fw_stoves[kk])))).concat(chK.map((kk) => cell(v.ch_stoves[kk], P1(v.ch_stoves[kk])))); }),
    withNat(dimKeys()).indexOf(state.focus));
  }

  // ------------------------------------------------------------------ COST
  const COST_METRICS = [
    { id: "lpg_refill_6", name: () => L("6 kg LPG refill", "Gesi kilo 6"), get: (v) => v.cost.lpg_refill_6, fmt: tzs, axis: tzsShort },
    { id: "lpg_refill_15", name: () => L("15 kg LPG refill", "Gesi kilo 15"), get: (v) => v.cost.lpg_refill_15, fmt: tzs, axis: tzsShort },
    { id: "lpg_month", name: () => L("LPG per month", "Gesi kwa mwezi"), get: (v) => v.cost.lpg_month, fmt: tzs, axis: tzsShort, n: (v) => v.cost.n_lpg },
    { id: "ch_month", name: () => L("Charcoal per month", "Mkaa kwa mwezi"), get: (v) => v.cost.ch_month, fmt: tzs, axis: tzsShort, n: (v) => v.cost.n_ch },
    { id: "fw_month", name: () => L("Firewood per month", "Kuni kwa mwezi"), get: (v) => v.cost.fw_month, fmt: tzs, axis: tzsShort, n: (v) => v.cost.n_fw },
    { id: "buys_fw", name: () => L("Firewood users who buy", "Watumiaji wa kuni wanaonunua"), get: (v) => v.cost.buys_fw, fmt: P1, axis: PA, cap: 1 },
  ];
  function renderCost() {
    const f = V[state.focus], nat = V.national, c = f.cost;
    const med = L("median price paid", "bei ya kati iliyolipwa");
    tiles("cost-tiles", [
      { label: L("6 kg LPG refill", "Kujaza gesi kilo 6"), value: tzs(c.lpg_refill_6), sub: natSub((v) => v.cost.lpg_refill_6, tzs) || med },
      { label: L("15 kg LPG refill", "Kujaza gesi kilo 15"), value: tzs(c.lpg_refill_15), sub: natSub((v) => v.cost.lpg_refill_15, tzs) || med },
      { label: L("LPG spending per month", "Matumizi ya gesi kwa mwezi"), value: tzs(c.lpg_month), sub: natSub((v) => v.cost.lpg_month, tzs) || L("median, LPG buyers", "thamani ya kati, wanunuzi wa gesi"), clean: true },
      { label: L("Charcoal spending per month", "Matumizi ya mkaa kwa mwezi"), value: tzs(c.ch_month), sub: natSub((v) => v.cost.ch_month, tzs) || L("median, charcoal buyers", "thamani ya kati, wanunuzi wa mkaa") },
    ]);
    clear($("cost-callout")).append(document.createTextNode(L(
      `In ${focusName()}, households that buy LPG spend a median of ${tzs(c.lpg_month)} a month on it, while charcoal buyers spend ${tzs(c.ch_month)}. ${pct(c.lpg_6_share)} of LPG users buy the small 6 kg cylinder, which keeps each purchase affordable but costs more per kilogram than the 15 kg size (${tzs(c.lpg_refill_6 / 6)} against ${tzs(c.lpg_refill_15 / 15)} per kg).`,
      `Katika ${focusName()}, kaya zinazonunua gesi hutumia kiasi cha kati cha ${tzs(c.lpg_month)} kwa mwezi, wakati wanunuzi wa mkaa hutumia ${tzs(c.ch_month)}. ${pct(c.lpg_6_share)} ya watumiaji wa gesi hununua mtungi mdogo wa kilo 6. Ni rahisi kununua kwa wakati mmoja, lakini ni ghali zaidi kwa kilo kuliko mtungi wa kilo 15 (${tzs(c.lpg_refill_6 / 6)} dhidi ya ${tzs(c.lpg_refill_15 / 15)} kwa kilo).`)));
    $("cost-a-desc").textContent = focusName() + L(" · median TZS per month among households that buy each fuel", " · shilingi za kati kwa mwezi kwa kaya zinazonunua nishati hiyo");
    hbar($("cost-a"), [["LPG", c.lpg_month, nat.cost.lpg_month, CLEAN(), c.n_lpg], ["Charcoal", c.ch_month, nat.cost.ch_month, POLL(), c.n_ch], ["Firewood", c.fw_month, nat.cost.fw_month, css("--s1"), c.n_fw]]
      .map(([l, v, nv, col, n]) => ({ label: tr(l), value: v, ref: isNat() ? null : nv, color: col, tip: { title: tr(l), rows: [{ color: col, value: tzs(v), label: L("median per month", "thamani ya kati kwa mwezi") }], sub: nf0.format(n) + L(" reporting households", " kaya zilizotoa taarifa") + (isNat() ? "" : " · " + mainland() + ": " + tzs(nv)) } })),
    { fmt: tzs, axisFmt: tzsShort, rowH: 34 });
    $("cost-b-desc").textContent = focusName() + L(" · share of users who buy the fuel rather than collect or make it", " · asilimia ya watumiaji wanaonunua badala ya kuokota au kutengeneza");
    hbar($("cost-b"), [[L("Firewood users who buy firewood", "Watumiaji wa kuni wanaonunua kuni"), c.buys_fw, nat.cost.buys_fw], [L("Charcoal users who buy charcoal", "Watumiaji wa mkaa wanaonunua mkaa"), c.buys_ch, nat.cost.buys_ch]]
      .map(([l, v, nv]) => ({ label: l, value: v, ref: isNat() ? null : nv, color: POLL(), tip: { title: l, rows: [{ color: POLL(), value: P1(v), label: focusName() }], sub: isNat() ? null : mainland() + ": " + P1(nv) } })),
    { fmt: P1, axisFmt: PA, max: 1, rowH: 34 });
    const m = COST_METRICS.find((x) => x.id === state.costMetric);
    seg($("cost-c-metric"), COST_METRICS, m.id, (id) => { state.costMetric = id; renderCost(); });
    $("cost-c-title").textContent = compareTitle();
    $("cost-c-desc").textContent = m.name() + (m.id.startsWith("buys") ? "" : L(" · median TZS", " · shilingi za kati")) + sortedNote();
    compare("cost-c", m, m.id.startsWith("lpg") ? CLEAN() : POLL());
    table("cost-table", [DIMS[state.dim].label(), L("6 kg refill (TZS)", "Gesi kilo 6 (TZS)"), L("15 kg refill (TZS)", "Gesi kilo 15 (TZS)"), L("LPG per month (TZS)", "Gesi kwa mwezi (TZS)"), L("Charcoal per month (TZS)", "Mkaa kwa mwezi (TZS)"), L("Firewood per month (TZS)", "Kuni kwa mwezi (TZS)"), L("Firewood users who buy", "Watumiaji wa kuni wanaonunua"), L("Charcoal users who buy", "Watumiaji wa mkaa wanaonunua"), L("LPG buyers (n)", "Wanunuzi wa gesi (idadi)"), L("Charcoal buyers (n)", "Wanunuzi wa mkaa (idadi)"), L("Firewood buyers (n)", "Wanunuzi wa kuni (idadi)")],
      withNat(dimKeys()).map((k) => { const x = V[k].cost; return [cell(label(k))].concat([x.lpg_refill_6, x.lpg_refill_15, x.lpg_month, x.ch_month, x.fw_month].map((y) => cell(y, y == null ? "–" : nf0.format(y)))).concat([cell(x.buys_fw, P1(x.buys_fw)), cell(x.buys_ch, P1(x.buys_ch)), cell(x.n_lpg, nf0.format(x.n_lpg)), cell(x.n_ch, nf0.format(x.n_ch)), cell(x.n_fw, nf0.format(x.n_fw))]); }),
      withNat(dimKeys()).indexOf(state.focus));
  }

  // ------------------------------------------------------------------ DRIVERS
  const OUTCOME_NAME = () => ({ primary_clean: L("clean main fuel", "nishati kuu safi"), any_clean: L("uses any clean fuel", "inatumia nishati safi yoyote") });
  function renderDrivers() {
    const y = state.drvOutcome, natv = V.national[y], on = OUTCOME_NAME();
    const small = (id, rows) => hbar($(id), rows.map((r) => ({ label: tr(r.label), value: r[y], color: CLEAN(),
      tip: { title: tr(r.label), rows: [{ color: CLEAN(), value: P1(r[y]), label: on[y] }], sub: P1(r.share) + L(" of households · n = ", " ya kaya · idadi = ") + nf0.format(r.n) } })),
    { fmt: P1, axisFmt: PA, cap: 1, ref: natv, refLabel: mainland(), rowH: 32 });
    small("drv-power", D.drivers.power); small("drv-educ", D.drivers.educ); small("drv-occ", D.drivers.occ); small("drv-hhsize", D.drivers.hhsize);
    $("drv-grid-desc").textContent = L("Share with a clean main fuel, by area and TANESCO grid connection", "Asilimia yenye nishati kuu safi, kwa eneo na kuunganishwa na gridi ya TANESCO");
    hbar($("drv-grid"), D.drivers.grid_by_area.map((r) => {
      const lb = tr(r.area) + " · " + tr(r.grid).toLowerCase();
      return { label: lb, value: r.primary_clean, color: CLEAN(), tip: { title: lb, rows: [{ color: CLEAN(), value: P1(r.primary_clean), label: on.primary_clean }, { color: css("--s1"), value: P1(r.lpg), label: L("use LPG", "wanatumia gesi") }], sub: L("n = ", "idadi = ") + nf0.format(r.n) } };
    }), { fmt: P1, axisFmt: PA, rowH: 32 });
    const mod = D.models2023[y];
    $("drv-ame-desc").textContent = L("Outcome: ", "Matokeo: ") + on[y] + L(" · HECS 2023, ", " · HECS 2023, kaya ") + nf0.format(mod.n) + L(" households · bold = statistically significant (p < 0.05)", " · herufi nzito = ina umuhimu wa kitakwimu (p < 0.05)");
    legend($("drv-ame-legend"), [{ name: L("Raises the probability", "Inaongeza uwezekano"), color: css("--s1") }, { name: L("Lowers the probability", "Inapunguza uwezekano"), color: css("--s8") }]);
    forest($("drv-ame"), mod.rows.map((r) => ({ label: tr(r.term), ame: r.ame, se: r.se, p: r.p })));
    const all = [[L("Electricity", "Umeme"), D.drivers.power], [L("Education of head", "Elimu ya mkuu wa kaya"), D.drivers.educ], [L("Livelihood of head", "Shughuli ya mkuu wa kaya"), D.drivers.occ], [L("Household size", "Ukubwa wa kaya"), D.drivers.hhsize], [L("Sex of head", "Jinsi ya mkuu wa kaya"), D.drivers.sex], [L("Area", "Eneo"), D.drivers.area]];
    const rows = [];
    all.forEach(([g, arr]) => arr.forEach((r) => rows.push([cell(g), cell(tr(r.label)), cell(r.n, nf0.format(r.n)), cell(r.share, P1(r.share)), cell(r.primary_clean, P1(r.primary_clean)), cell(r.any_clean, P1(r.any_clean)), cell(r.lpg, P1(r.lpg)), cell(r.electric, P1(r.electric)), cell(r.primary_clean_or_ics, P1(r.primary_clean_or_ics))])));
    mod.rows.forEach((r) => rows.push([cell(L("Model (", "Modeli (") + on[y] + ")"), cell(tr(r.term)), cell(""), cell(""), cell(r.ame, pp(r.ame, 2)), cell(r.se, "se " + (r.se * 100).toFixed(2)), cell(r.p, r.p < 0.001 ? "p<0.001" : "p=" + r.p.toFixed(3)), cell(""), cell("")]));
    table("drv-table", [L("Factor", "Kipengele"), L("Group", "Kundi"), L("Households (n)", "Kaya (idadi)"), L("Share of households", "Asilimia ya kaya"), L("Clean main fuel", "Nishati kuu safi"), L("Any clean fuel", "Nishati safi yoyote"), L("Uses LPG", "Inatumia gesi"), L("Uses electricity", "Inatumia umeme"), L("Clean or improved main", "Kuu safi au jiko banifu")], rows);
  }

  // ------------------------------------------------------------------ PROGRESS
  const MILESTONES = [
    ["2024-01", "Ban on firewood and charcoal in institutions that cook for more than 100 people (31,395 institutions)", "Marufuku ya kuni na mkaa kwenye taasisi zinazopikia zaidi ya watu 100 (taasisi 31,395)"],
    ["2024-07", "Subsidies for clean cooking projects increased", "Ruzuku kwa miradi ya nishati safi ya kupikia kuongezwa"],
    ["2024-09", "National communication strategy and awareness plan on clean cooking implemented", "Mkakati wa mawasiliano na mpango wa kuelimisha umma kuhusu nishati safi kutekelezwa"],
    ["2025-06", "Electric cookstoves and appliances payable through the LUKU prepaid electricity system", "Majiko ya umeme kulipiwa kupitia mfumo wa LUKU"],
    ["2025-06", "Financial institutions offer low-interest loans to clean cooking businesses", "Taasisi za fedha kutoa mikopo yenye riba nafuu kwa biashara za nishati safi"],
    ["2025-07", "Electric stoves manufactured in Tanzania", "Majiko ya umeme kuanza kutengenezwa Tanzania"],
    ["2025-07", "System to pay for clean cooking through affordable loans in place", "Mfumo wa kulipia nishati safi kwa mikopo nafuu kuwekwa"],
    ["2026-06", "Taxes and fees on clean cooking energy, appliances and efficient stoves reduced", "Kodi na tozo kwenye nishati safi, vifaa na majiko banifu kupunguzwa"],
    ["2028-06", "Electricity distribution reaches all villages and hamlets", "Umeme kufika vijiji na vitongoji vyote"],
    ["2029-06", "LPG import terminals able to receive vessels of up to 40,000 tonnes; LPG storage in all regions", "Bandari kupokea meli za gesi hadi tani 40,000; maghala ya gesi katika mikoa yote"],
    ["2034-06", "Natural gas distribution expanded from 4 to 9 regions; pay-as-you-go clean cooking in every region", "Gesi asilia kusambazwa kutoka mikoa 4 hadi 9; mfumo wa lipa kadri unavyotumia katika kila mkoa"],
    ["2034-12", "80% of Tanzanians use clean cooking solutions", "80% ya Watanzania kutumia nishati safi ya kupikia"],
  ];
  const MONTHS_EN = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const MONTHS_SW = ["Jan", "Feb", "Mac", "Apr", "Mei", "Jun", "Jul", "Ago", "Sep", "Okt", "Nov", "Des"];
  function renderProgress() {
    const p = pace();
    tiles("prog-tiles", [
      { label: L("Clean main fuel, 2017-18", "Nishati kuu safi, 2017-18"), value: P1(p.pts[0].v), sub: "HBS 2017-18" },
      { label: L("Clean main fuel, 2023", "Nishati kuu safi, 2023"), value: P1(p.last.v), sub: "HECS 2023", clean: true },
      { label: L("Observed pace", "Kasi iliyopo"), value: ppyr(p.slope), sub: L("trend across the three surveys", "mwenendo wa tafiti tatu") },
      { label: L("Pace needed for 80% by 2034", "Kasi inayohitajika kufikia 80% ifikapo 2034"), value: ppyr(p.needed),
        sub: L(`about ${(p.needed / p.slope).toFixed(1)}× faster; at today's pace ≈ ${pct(p.proj2034)} by 2034`, `takriban mara ${(p.needed / p.slope).toFixed(1)} zaidi; kwa kasi ya sasa ≈ ${pct(p.proj2034)} ifikapo 2034`) },
    ]);
    const host = clear($("prog-a"));
    const width = Math.max(340, host.clientWidth || 800), H = 320, padL = 46, padR = 20, padT = 14, padB = 34;
    const x0 = 2017, x1 = 2035, X = (v) => padL + ((v - x0) / (x1 - x0)) * (width - padL - padR), Y = (v) => padT + (1 - v) * (H - padT - padB);
    const svg = s("svg", { viewBox: `0 0 ${width} ${H}`, role: "img", "aria-label": L("Clean cooking trend and target", "Mwenendo wa nishati safi na lengo") });
    for (let i = 0; i <= 5; i++) {
      const v = i / 5;
      svg.append(s("line", { x1: padL, x2: width - padR, y1: Y(v), y2: Y(v), stroke: i === 0 ? css("--baseline") : css("--grid") }));
      svg.append(s("text", { x: padL - 6, y: Y(v) + 4, "text-anchor": "end", "font-size": 11, fill: css("--axis-muted"), text: (v * 100).toFixed(0) + "%" }));
    }
    const stepYr = width < 600 ? 4 : 2;
    for (let yv = 2018; yv <= 2034; yv += stepYr) svg.append(s("text", { x: X(yv), y: H - 12, "text-anchor": "middle", "font-size": 11, fill: css("--axis-muted"), text: String(yv) }));
    const obs = css("--s1"), need = css("--s2");
    const proj = (yr) => p.last.v + p.slope * (yr - p.last.year);
    svg.append(s("path", { d: `M${X(p.pts[0].year)},${Y(p.pts[0].v)}` + p.pts.slice(1).map((q) => `L${X(q.year)},${Y(q.v)}`).join(""), fill: "none", stroke: obs, "stroke-width": 2, "stroke-linejoin": "round" }));
    svg.append(s("path", { d: `M${X(p.last.year)},${Y(p.last.v)}L${X(2034.5)},${Y(proj(2034.5))}`, fill: "none", stroke: obs, "stroke-width": 2, "stroke-dasharray": "5 5" }));
    svg.append(s("path", { d: `M${X(p.last.year)},${Y(p.last.v)}L${X(2034.5)},${Y(0.8)}`, fill: "none", stroke: need, "stroke-width": 2, "stroke-dasharray": "5 5" }));
    svg.append(s("circle", { cx: X(2034.5), cy: Y(0.8), r: 6, fill: need, stroke: css("--surface-1"), "stroke-width": 2 }));
    svg.append(s("text", { x: X(2034.5) - 10, y: Y(0.8) - 10, "text-anchor": "end", "font-size": 12, "font-weight": 600, fill: css("--text-primary"), text: L("Target 80% (2034)", "Lengo 80% (2034)") }));
    svg.append(s("text", { x: X(2034.5) - 10, y: Y(proj(2034.5)) - 10, "text-anchor": "end", "font-size": 12, fill: css("--text-secondary"), text: L("At today's pace ≈ ", "Kwa kasi ya sasa ≈ ") + pct(proj(2034.5)) }));
    p.pts.forEach((q) => {
      const g = s("g");
      g.append(s("circle", { cx: X(q.year), cy: Y(q.v), r: 5, fill: obs, stroke: css("--surface-1"), "stroke-width": 2 }));
      g.append(s("text", { x: X(q.year), y: Y(q.v) - 12, "text-anchor": "middle", "font-size": 11.5, fill: css("--text-secondary"), text: P1(q.v) }));
      g.append(s("circle", { cx: X(q.year), cy: Y(q.v), r: 14, fill: "transparent" }));
      bindTip(g, () => ({ title: q.label, rows: [{ color: obs, value: P1(q.v), label: L("main cooking fuel is clean", "nishati kuu ya kupikia ni safi") }] }));
      svg.append(g);
    });
    host.append(svg);
    legend($("prog-a-legend"), [{ name: L("Observed (survey estimates and trend)", "Hali halisi (matokeo ya tafiti na mwenendo)"), color: obs }, { name: L("Path needed for 80% by 2034", "Njia inayohitajika kufikia 80% ifikapo 2034"), color: need }], "line");
    seg($("prog-b-area"), [{ id: "national", name: L("Mainland", "Tanzania Bara") }, { id: "Rural", name: tr("Rural") }, { id: "Urban", name: tr("Urban") }], state.progArea, (id) => { state.progArea = id; renderProgress(); });
    const gs = groupSeries();
    legend($("prog-b-legend"), gs);
    $("prog-b-desc").textContent = L("Share of households by main cooking fuel · ", "Asilimia ya kaya kwa nishati kuu ya kupikia · ") + (state.progArea === "national" ? label("national") : tr(state.progArea));
    stacked($("prog-b"), ["HBS 2017-18", "IASES 2021-22", "HECS 2023"].map((k) => ({ label: k.replace("2021-22", "2021/22"), parts: groupParts(D.trend[k][state.progArea] || {}) })), gs, { rowH: 40 });
    const ul = clear($("milestones"));
    const now = new Date().toISOString().slice(0, 7);
    MILESTONES.forEach(([ym, en, sw]) => {
      const past = ym < now, mo = +ym.slice(5, 7) - 1, yr = ym.slice(0, 4);
      const when = ym.endsWith("-12") && yr === "2034" ? yr : (LANG === "sw" ? MONTHS_SW : MONTHS_EN)[mo] + " " + yr;
      ul.append(el("li", { class: past ? "past" : "" }, el("div", { class: "when" }, document.createTextNode(when), el("span", { class: "pill", text: past ? L("date passed", "tarehe imepita") : L("upcoming", "inakuja") })), el("div", { class: "what", text: L(en, sw) })));
    });
  }

  // ------------------------------------------------------------------ ABOUT
  function renderAbout() {
    const bio = clear($("bio"));
    bio.append(
      el("p", { text: L(
        "A. Ahmed Abdallah is an energy economist and Assistant Lecturer in the School of Economics at the University of Dar es Salaam. He is also Data Manager for the Environment for Development (EfD) initiative at the university, where he designs data management plans, oversees digital surveys and quality control, and curates research data for sharing with the EfD Global Hub.",
        "A. Ahmed Abdallah ni mchumi wa nishati na Mhadhiri Msaidizi katika Shule Kuu ya Uchumi, Chuo Kikuu cha Dar es Salaam. Pia ni Meneja wa Takwimu wa mpango wa Environment for Development (EfD) chuoni hapo, ambapo anaandaa mipango ya usimamizi wa takwimu, anasimamia tafiti za kidijitali na ubora wa takwimu, na anahifadhi takwimu za utafiti kwa ajili ya kushirikishwa na EfD duniani.") }),
      el("p", { text: L(
        "He holds a BA in Economics from the University of Dar es Salaam and a Master of Energy Economics and Governance from Makerere University Business School, funded by a NORHED II scholarship, and is completing an MA in Economics at the University of Dar es Salaam. His research interests are energy economics, environmental policy and sustainable development, with a focus on household energy transitions in Tanzania.",
        "Ana Shahada ya Kwanza ya Uchumi kutoka Chuo Kikuu cha Dar es Salaam na Shahada ya Uzamili ya Uchumi na Utawala wa Nishati kutoka Makerere University Business School kwa ufadhili wa NORHED II. Kwa sasa anakamilisha Shahada ya Uzamili ya Uchumi (MA) katika Chuo Kikuu cha Dar es Salaam. Maeneo yake ya utafiti ni uchumi wa nishati, sera za mazingira na maendeleo endelevu, hasa mabadiliko ya matumizi ya nishati katika kaya za Tanzania.") }),
      el("ul", null,
        el("li", { text: L("Energy consultant, Energy Hub Tanzania: hosted a webinar series on how Tanzania's energy sector can be financed (2026).", "Mshauri wa nishati, Energy Hub Tanzania: aliendesha mfululizo wa semina za mtandaoni kuhusu jinsi ya kugharamia sekta ya nishati Tanzania (2026).") }),
        el("li", { text: L("Data collection supervisor and trainer for a study on generative AI tools among young people in Dar es Salaam (2025).", "Msimamizi na mkufunzi wa ukusanyaji wa takwimu kwa utafiti wa zana za akili bandia (AI) kwa vijana wa Dar es Salaam (2025).") }),
        el("li", { text: L("Trained in KoboToolbox, Survey Solutions, and data curation with the Swedish National Data Service (DORIS).", "Amepata mafunzo ya KoboToolbox, Survey Solutions, na uhifadhi wa takwimu na Swedish National Data Service (DORIS).") }),
        el("li", { text: L("Languages: Kiswahili, English, Chinese (HSK II).", "Lugha: Kiswahili, Kiingereza, Kichina (HSK II).") })));
    const host = clear($("about-body"));
    const h2 = (t) => el("h2", { text: t }), p = (t) => el("p", { text: t });
    const ul = (items) => el("ul", null, ...items.map((t) => el("li", { text: t })));
    host.append(
      h2(L("About Kupika Safi", "Kuhusu Kupika Safi")),
      p(L("Kupika Safi (Swahili for “clean cooking”) is an independent observatory on household cooking energy in Tanzania. It turns national survey microdata into open, interactive evidence for policymakers, researchers, development partners, the private sector and the public, in support of the National Clean Cooking Strategy 2024–2034.",
        "Kupika Safi ni kituo huru cha takwimu kuhusu nishati ya kupikia katika kaya za Tanzania. Kinageuza takwimu za tafiti za kitaifa kuwa taarifa wazi na rahisi kutumia kwa watunga sera, watafiti, washirika wa maendeleo, sekta binafsi na umma, kwa kuunga mkono Mkakati wa Taifa wa Nishati Safi ya Kupikia 2024–2034.")),
      h2(L("Data sources", "Vyanzo vya takwimu")),
      ul([
        L(`2023 Household Energy Consumption Survey (HECS), National Bureau of Statistics and Ministry of Energy, with Expertise France and the European Union. ${nf0.format(M.n_households)} households in all 26 regions of Mainland Tanzania. Used for most of the site.`,
          `Utafiti wa Matumizi ya Nishati katika Kaya 2023 (HECS), Ofisi ya Taifa ya Takwimu na Wizara ya Nishati, kwa msaada wa Expertise France na Umoja wa Ulaya. Kaya ${nf0.format(M.n_households)} katika mikoa yote 26 ya Tanzania Bara. Umetumika kwa sehemu kubwa ya tovuti.`),
        L(`Impact of Access to Sustainable Energy Survey (IASES) 2021/22, NBS and Statistics Norway. ${nf0.format(D.iases.desc.n)} households. Used for the 2021/22 trend point (main source of energy for cooking).`,
          `Utafiti wa Athari za Upatikanaji wa Nishati Endelevu (IASES) 2021/22, NBS na Takwimu Norway. Kaya ${nf0.format(D.iases.desc.n)}. Umetumika kwa takwimu za 2021/22 kwenye mwenendo (chanzo kikuu cha nishati ya kupikia).`),
        L("Household Budget Survey (HBS) 2017-18, NBS: main source of energy for cooking. Used for the 2017-18 trend point.", "Utafiti wa Bajeti ya Kaya (HBS) 2017-18, NBS: chanzo kikuu cha nishati ya kupikia. Umetumika kwa takwimu za 2017-18 kwenye mwenendo."),
        L("National Clean Cooking Strategy 2024–2034, Ministry of Energy: targets and milestones.", "Mkakati wa Taifa wa Nishati Safi ya Kupikia 2024–2034, Wizara ya Nishati: malengo na hatua muhimu."),
      ]),
      h2(L("Key definitions", "Maana ya maneno muhimu")),
      ul([
        L("Clean fuels follow the WHO definition used for SDG indicator 7.1.2: electricity, LPG, natural gas, biogas and bioethanol (and solar). Firewood, charcoal, crop residues and kerosene are polluting fuels.", "Nishati safi ni kwa ufafanuzi wa WHO (kiashiria cha SDG 7.1.2): umeme, gesi (LPG), gesi asilia, biogesi na bioethanoli (na sola). Kuni, mkaa, mabaki ya mazao na mafuta ya taa ni nishati chafu."),
        L("Main fuel (HECS 2023) is the fuel used for the most cooking sessions per week. Where two fuels tie, the more polluting one is counted, so clean cooking is not overstated.", "Nishati kuu (HECS 2023) ni ile inayotumika kupika mara nyingi zaidi kwa wiki. Nishati mbili zikilingana, tunahesabu ile chafu zaidi ili tusizidishe kiwango cha nishati safi."),
        L("Stacking is using at least one clean fuel and at least one polluting fuel.", "Kuchanganya nishati ni kutumia angalau nishati safi moja pamoja na angalau nishati chafu moja."),
        L("Improved cookstoves are the stove types HECS records as improved. The strategy counts standard-compliant improved stoves as clean; WHO does not. The site therefore shows both “clean main fuel” and “clean or improved main fuel”.", "Majiko banifu ni aina za majiko ambazo HECS imerekodi kama banifu. Mkakati unahesabu majiko banifu yanayokidhi viwango kuwa safi; WHO haiyahesabu. Kwa hiyo tovuti inaonyesha “nishati kuu safi” na “nishati kuu safi au jiko banifu”."),
      ]),
      h2(L("Methods", "Mbinu")),
      ul([
        L("All estimates are weighted with each survey's household weights. HECS fuel-use shares reproduce the published HECS 2023 report (firewood 65.5%, charcoal 44.0%, LPG 24.6%, rural firewood 89.6%, indoor cooking 42%), and HBS 2017-18 reproduces the shares cited in the strategy (rural firewood 84.8%, urban charcoal 60.5%).", "Makadirio yote yamepimwa kwa uzito wa kila utafiti. Matokeo ya HECS yanalingana na ripoti rasmi ya HECS 2023 (kuni 65.5%, mkaa 44.0%, gesi 24.6%, kuni vijijini 89.6%, kupikia ndani 42%), na HBS 2017-18 inalingana na takwimu zilizotajwa kwenye mkakati (kuni vijijini 84.8%, mkaa mijini 60.5%)."),
        L("Regression models are survey-weighted logits with standard errors clustered by enumeration area. Results are average marginal effects: the change in the probability of the outcome, in percentage points.", "Modeli za regresheni ni logit zilizopimwa kwa uzito wa utafiti. Matokeo ni athari za wastani: mabadiliko ya uwezekano, kwa pointi za asilimia."),
        L("Fuel spending is the survey-weighted median among households that buy each fuel, after excluding the top 1% of reported amounts.", "Matumizi ya nishati ni thamani ya kati kati ya kaya zinazonunua nishati hiyo, baada ya kuondoa asilimia 1 ya juu kabisa."),
      ]),
      h2(L("Limitations", "Mapungufu")),
      ul([
        L("These are cross-sectional surveys. The models describe associations, not proven causes.", "Hizi ni tafiti za wakati mmoja. Modeli zinaonyesha uhusiano, si chanzo kilichothibitishwa."),
        L("The three surveys ask about cooking fuel in different ways, so the trend across them is indicative.", "Tafiti tatu ziliuliza kuhusu nishati ya kupikia kwa njia tofauti, hivyo mwenendo ni wa kukadiria."),
        L("The strategy's 80% target refers to people and includes improved stoves; this site reports households.", "Lengo la 80% la mkakati ni kwa watu na linajumuisha majiko banifu; tovuti hii inaripoti kaya."),
        L("Spending is self-reported, and charcoal is sold in units of varying size.", "Matumizi yameripotiwa na kaya zenyewe, na mkaa unauzwa kwa vipimo tofauti."),
      ]),
      h2(L("How to cite", "Jinsi ya kunukuu")),
      p("Abdallah, A. A. (2026). Kupika Safi: Tanzania Clean Cooking Observatory. Interactive dashboards based on NBS HECS 2023, IASES 2021/22 and HBS 2017-18 microdata."),
    );
  }

  // ------------------------------------------------------------------ routing
  const ROUTES = ["home", "fuels", "stoves", "cost", "drivers", "progress", "about", "contact"];
  const current = () => { const h = location.hash.replace("#", ""); return ROUTES.includes(h) ? h : "home"; };
  const RENDER = { home: renderHome, fuels: renderFuels, stoves: renderStoves, cost: renderCost, drivers: renderDrivers, progress: renderProgress, about: renderAbout, contact: () => {} };
  function renderAll() { const r = current(); buildFilters(r); RENDER[r](); }
  function route() {
    const r = current();
    document.querySelectorAll(".view").forEach((v) => (v.hidden = v.dataset.view !== r));
    document.querySelectorAll(".side nav a").forEach((a) => (a.dataset.route === r ? a.setAttribute("aria-current", "page") : a.removeAttribute("aria-current")));
    Z.hideTip();
    renderAll();
    window.scrollTo(0, 0);
  }
  window.addEventListener("hashchange", route);
  let rt;
  window.addEventListener("resize", () => { clearTimeout(rt); rt = setTimeout(renderAll, 150); });
  const root = document.documentElement;
  try { const t = localStorage.getItem("ks-theme"); if (t) root.dataset.theme = t; } catch (e) { /* storage unavailable */ }
  $("themeBtn").addEventListener("click", () => {
    root.dataset.theme = isDark() ? "light" : "dark";
    try { localStorage.setItem("ks-theme", root.dataset.theme); } catch (e) { /* ignore */ }
    renderAll();
  });
  document.querySelectorAll("[data-lang]").forEach((b) => b.addEventListener("click", () => {
    LANG = b.dataset.lang;
    try { localStorage.setItem("ks-lang", LANG); } catch (e) { /* ignore */ }
    applyStatic();
    renderAll();
  }));
  matchMedia("(prefers-color-scheme: dark)").addEventListener("change", renderAll);
  if (Z.embedded) document.querySelectorAll(".dl-only").forEach((b) => b.remove());
  document.addEventListener("click", (e) => {
    const b = e.target.closest("[data-copy-text]");
    if (!b) return;
    const txt = b.dataset.copyText;
    (navigator.clipboard ? navigator.clipboard.writeText(txt) : Promise.reject()).then(() => Z.toast(L("Copied: ", "Imenakiliwa: ") + txt), () => Z.toast(L("Copy not available here: ", "Kunakili hakuwezekani hapa: ") + txt));
  });
  applyStatic();
  route();
})();
