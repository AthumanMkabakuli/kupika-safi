/* Shared chart toolkit (plain SVG, no dependencies). Exposes window.Viz. */
(function () {
  "use strict";
  const SVGNS = "http://www.w3.org/2000/svg";
  // ------------------------------------------------------------------ formatting
  const nf0 = new Intl.NumberFormat("en-US", { maximumFractionDigits: 0 });
  const nf1 = new Intl.NumberFormat("en-US", { maximumFractionDigits: 1, minimumFractionDigits: 1 });
  const tzs = (x) => (x == null ? "–" : "TZS " + nf0.format(Math.round(x)));
  const tzsShort = (x) => (x == null ? "–" : x >= 10000 ? nf1.format(x / 1000) + "K" : nf0.format(Math.round(x)));
  const pct = (x, d = 0) => (x == null ? "–" : (x * 100).toFixed(d) + "%");
  const pctAxis = (v) => { const q = v * 100; return (Math.abs(q - Math.round(q)) < 1e-6 ? q.toFixed(0) : q.toFixed(1)) + "%"; };
  const tickText = (fmt, v) => { const t = String(fmt(v)); return /%$/.test(t) ? pctAxis(v) : t; };
  const num1 = (x) => (x == null ? "–" : nf1.format(x));
  const num2 = (x) => (x == null ? "–" : x.toFixed(2));
  const css = (name) => getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  const SERIES = ["--s1", "--s2", "--s3", "--s4", "--s5", "--s6", "--s7", "--s8"];

  // ------------------------------------------------------------------ DOM helpers
  function el(tag, attrs, ...kids) {
    const n = document.createElement(tag);
    if (attrs) for (const [k, v] of Object.entries(attrs)) {
      if (k === "text") n.textContent = v;
      else if (k === "class") n.className = v;
      else if (k.startsWith("on")) n.addEventListener(k.slice(2), v);
      else if (v !== undefined && v !== null && v !== false) n.setAttribute(k, v);
    }
    for (const c of kids) if (c != null) n.append(c);
    return n;
  }
  function s(tag, attrs, ...kids) {
    const n = document.createElementNS(SVGNS, tag);
    if (attrs) for (const [k, v] of Object.entries(attrs)) {
      if (k === "text") n.textContent = v;
      else if (v !== undefined && v !== null) n.setAttribute(k, v);
    }
    for (const c of kids) if (c != null) n.append(c);
    return n;
  }
  const $ = (id) => document.getElementById(id);
  function clear(node) { while (node.firstChild) node.removeChild(node.firstChild); return node; }
  const textW = (str, size = 12) => str.length * size * 0.56;

  // ------------------------------------------------------------------ tooltip
  const tip = $("tip");
  function showTip(evt, spec) {
    clear(tip);
    if (spec.title) tip.append(el("div", { class: "t-title", text: spec.title }));
    for (const r of spec.rows || []) {
      const row = el("div", { class: "t-row" });
      if (r.color) row.append(el("span", { class: "t-key", style: "background:" + r.color }));
      row.append(el("b", { text: r.value }));
      if (r.label) row.append(el("span", { text: r.label }));
      tip.append(row);
    }
    if (spec.sub) tip.append(el("div", { class: "t-sub", text: spec.sub }));
    tip.classList.add("on");
    moveTip(evt);
  }
  function moveTip(evt) {
    let x, y;
    if (evt.clientX != null && evt.type !== "focus") { x = evt.clientX; y = evt.clientY; }
    else { const r = evt.target.getBoundingClientRect(); x = r.left + r.width / 2; y = r.top; }
    const w = tip.offsetWidth, h = tip.offsetHeight;
    let left = x + 14, top = y - h - 10;
    if (left + w > window.innerWidth - 8) left = x - w - 14;
    if (top < 8) top = y + 16;
    tip.style.left = Math.max(8, left) + "px";
    tip.style.top = top + "px";
  }
  function hideTip() { tip.classList.remove("on"); }
  function bindTip(node, specFn) {
    node.setAttribute("tabindex", "0");
    node.classList.add("mark");
    node.addEventListener("pointerenter", (e) => showTip(e, specFn()));
    node.addEventListener("pointermove", moveTip);
    node.addEventListener("pointerleave", hideTip);
    node.addEventListener("focus", (e) => showTip(e, specFn()));
    node.addEventListener("blur", hideTip);
  }

  // ------------------------------------------------------------------ charts
  /** Nice axis: returns {max, step, ticks} with 3-6 ticks of 1/2/2.5/5 x 10^n. */
  function niceScale(v, cap) {
    if (!(v > 0)) v = 1;
    const raw = v / 4;
    const p = Math.pow(10, Math.floor(Math.log10(raw)));
    const m = raw / p;
    const step = (m <= 1 ? 1 : m <= 2 ? 2 : m <= 2.5 ? 2.5 : m <= 5 ? 5 : 10) * p;
    let max = Math.ceil(v / step - 1e-9) * step;
    if (cap != null && max > cap) max = cap;
    return { max, step, ticks: Math.round(max / step) };
  }

  /** Horizontal bar chart. rows: [{label, value, color, highlight, tip}] */
  function hbar(container, rows, opt) {
    const o = Object.assign({ fmt: (v) => v, max: null, ref: null, refLabel: "National", rowH: 26, labelW: null }, opt);
    clear(container);
    const width = Math.max(320, container.clientWidth || 600);
    const labelW = o.labelW || Math.min(220, Math.max(90, ...rows.map((r) => textW(r.label, 12) + 10)));
    const valW = Math.max(...rows.map((r) => textW(o.fmt(r.value), 12))) + 12;
    const plotW = width - labelW - valW - 8;
    const padT = o.ref != null ? 16 : 0;
    const height = rows.length * o.rowH + 22 + padT;
    const sc = o.max != null ? { max: o.max, ticks: o.ticks || 4 } : niceScale(Math.max(...rows.map((r) => r.value || 0), o.ref || 0), o.cap);
    const max = sc.max;
    const x = (v) => labelW + (Math.max(0, v) / max) * plotW;
    const svg = s("svg", { viewBox: `0 0 ${width} ${height}`, role: "img", "aria-label": o.aria || "Bar chart" });
    // gridlines
    for (let i = 0; i <= sc.ticks; i++) {
      const gx = labelW + (plotW * i) / sc.ticks;
      svg.append(s("line", { x1: gx, x2: gx, y1: padT, y2: height - 18, stroke: i === 0 ? css("--baseline") : css("--grid"), "stroke-width": 1 }));
      svg.append(s("text", { x: gx, y: height - 4, "text-anchor": i === 0 ? "start" : i === sc.ticks ? "end" : "middle", "font-size": 11, fill: css("--axis-muted"), text: tickText(o.axisFmt || o.fmt, (max * i) / sc.ticks) }));
    }
    rows.forEach((r, i) => {
      const y = padT + i * o.rowH;
      const bh = Math.min(16, o.rowH - 8);
      const by = y + (o.rowH - bh) / 2;
      const g = s("g");
      g.append(s("rect", { x: 0, y, width, height: o.rowH, fill: r.highlight ? css("--accent-wash") : "transparent" }));
      g.append(s("text", { x: labelW - 8, y: y + o.rowH / 2 + 4, "text-anchor": "end", "font-size": 12, fill: css("--text-primary"), "font-weight": r.highlight ? 650 : 400, text: r.label }));
      const w = Math.max(0, x(r.value || 0) - labelW);
      if (w > 0) {
        const rr = Math.min(4, w / 2);
        g.append(s("path", { d: `M${labelW},${by}h${w - rr}a${rr},${rr} 0 0 1 ${rr},${rr}v${bh - 2 * rr}a${rr},${rr} 0 0 1 -${rr},${rr}h-${w - rr}z`, fill: r.color || css("--s1") }));
      }
      g.append(s("text", { x: x(r.value || 0) + 6, y: y + o.rowH / 2 + 4, "font-size": 12, fill: css("--text-secondary"), text: o.fmt(r.value) }));
      if (r.ref != null) {
        const rx = x(r.ref);
        g.append(s("line", { x1: rx, x2: rx, y1: by - 3, y2: by + bh + 3, stroke: css("--text-primary"), "stroke-width": 2, "stroke-linecap": "round" }));
      }
      if (r.tip) bindTip(g, () => r.tip);
      svg.append(g);
    });
    if (o.ref != null) {
      const rx = x(o.ref);
      svg.append(s("line", { x1: rx, x2: rx, y1: 4, y2: height - 18, stroke: css("--text-secondary"), "stroke-width": 1 }));
      const lbl = o.refLabel + " " + o.fmt(o.ref);
      const anchorEnd = rx + textW(lbl, 10.5) + 6 > width;
      svg.append(s("text", { x: anchorEnd ? rx - 4 : rx + 4, y: 11, "text-anchor": anchorEnd ? "end" : "start", "font-size": 10.5, fill: css("--text-secondary"), text: lbl }));
    }
    container.append(svg);
  }

  /** 100% stacked horizontal bars. rows: [{label, parts:[number], highlight}] series:[{name,color}] */
  function stacked(container, rows, series, opt) {
    const o = Object.assign({ fmt: (v) => pct(v), rowH: 30, partFmt: null }, opt);
    clear(container);
    const width = Math.max(320, container.clientWidth || 600);
    const labelW = Math.min(200, Math.max(90, ...rows.map((r) => textW(r.label, 12) + 12)));
    const plotW = width - labelW - 4;
    const height = rows.length * o.rowH + 4;
    const svg = s("svg", { viewBox: `0 0 ${width} ${height}`, role: "img", "aria-label": o.aria || "Stacked bar chart" });
    rows.forEach((r, i) => {
      const y = i * o.rowH;
      const bh = Math.min(22, o.rowH - 6);
      const by = y + (o.rowH - bh) / 2;
      if (r.highlight) svg.append(s("rect", { x: 0, y, width, height: o.rowH, fill: css("--accent-wash") }));
      svg.append(s("text", { x: labelW - 8, y: y + o.rowH / 2 + 4, "text-anchor": "end", "font-size": 12, fill: css("--text-primary"), "font-weight": r.highlight ? 650 : 400, text: r.label }));
      const total = r.parts.reduce((a, b) => a + (b || 0), 0) || 1;
      let cx = labelW;
      r.parts.forEach((v, j) => {
        const share = (v || 0) / total;
        const w = share * plotW;
        if (w <= 0) return;
        const gap = j < r.parts.length - 1 ? 2 : 0;
        const g = s("g");
        g.append(s("rect", { x: cx, y: by, width: Math.max(0.5, w - gap), height: bh, rx: 3, fill: series[j].color }));
        const lab = pct(share);
        if (w - gap > textW(lab, 11) + 10) {
          const dark = series[j].ink === "dark";
          g.append(s("text", { x: cx + 5, y: by + bh / 2 + 4, "font-size": 11, fill: dark ? "#0b0b0b" : "#ffffff", "font-weight": 600, text: lab }));
        }
        bindTip(g, () => ({ title: r.label, rows: [{ color: series[j].color, value: pct(share, 1), label: series[j].name }], sub: o.partFmt ? o.partFmt(v, r, j) : null }));
        svg.append(g);
        cx += w;
      });
    });
    container.append(svg);
  }

  /** Vertical columns. cats:[label], vals:[number] */
  function columns(container, cats, vals, opt) {
    const o = Object.assign({ fmt: (v) => pct(v), color: css("--s1"), height: 220, refVals: null, xTitle: "" }, opt);
    clear(container);
    const width = Math.max(300, container.clientWidth || 500);
    const padL = 36, padB = o.xTitle ? 40 : 24, padT = 18;
    const plotH = o.height - padB - padT;
    const plotW = width - padL - 8;
    const sc = niceScale(Math.max(...vals, ...(o.refVals || [0])), 1);
    const max = sc.max;
    const svg = s("svg", { viewBox: `0 0 ${width} ${o.height}`, role: "img", "aria-label": o.aria || "Column chart" });
    for (let i = 0; i <= sc.ticks; i++) {
      const gy = padT + plotH - (plotH * i) / sc.ticks;
      svg.append(s("line", { x1: padL, x2: width - 8, y1: gy, y2: gy, stroke: i === 0 ? css("--baseline") : css("--grid") }));
      svg.append(s("text", { x: padL - 6, y: gy + 4, "text-anchor": "end", "font-size": 11, fill: css("--axis-muted"), text: tickText(o.fmt, (max * i) / sc.ticks) }));
    }
    const band = plotW / cats.length;
    const bw = Math.min(28, band * 0.6);
    cats.forEach((c, i) => {
      const v = vals[i] || 0;
      const h = (v / max) * plotH;
      const bx = padL + band * i + (band - bw) / 2;
      const by = padT + plotH - h;
      const g = s("g");
      g.append(s("rect", { x: padL + band * i, y: padT, width: band, height: plotH, fill: "transparent" }));
      if (h > 0) {
        const rr = Math.min(4, h / 2, bw / 2);
        g.append(s("path", { d: `M${bx},${by + h}v-${h - rr}a${rr},${rr} 0 0 1 ${rr},-${rr}h${bw - 2 * rr}a${rr},${rr} 0 0 1 ${rr},${rr}v${h - rr}z`, fill: o.color }));
      }
      g.append(s("text", { x: bx + bw / 2, y: by - 5, "text-anchor": "middle", "font-size": 11, fill: css("--text-secondary"), text: o.fmt(v) }));
      if (o.refVals) {
        const ry = padT + plotH - (o.refVals[i] / max) * plotH;
        g.append(s("line", { x1: bx - 3, x2: bx + bw + 3, y1: ry, y2: ry, stroke: css("--text-primary"), "stroke-width": 2, "stroke-linecap": "round" }));
      }
      g.append(s("text", { x: bx + bw / 2, y: padT + plotH + 15, "text-anchor": "middle", "font-size": 11.5, fill: css("--text-secondary"), text: c }));
      if (o.tip) bindTip(g, () => o.tip(i));
      svg.append(g);
    });
    if (o.xTitle) svg.append(s("text", { x: padL + plotW / 2, y: o.height - 4, "text-anchor": "middle", "font-size": 11.5, fill: css("--axis-muted"), text: o.xTitle }));
    container.append(svg);
  }

  /** Line chart with crosshair. x: [number], series: [{name,color,values}] */
  function lines(container, xs, series, opt) {
    const o = Object.assign({ height: 300, marker: null, xFmt: (v) => v, yFmt: (v) => pct(v), xTitle: "" }, opt);
    clear(container);
    const width = Math.max(320, container.clientWidth || 700);
    const narrow = width < 600;
    const padL = 44, padR = narrow ? 12 : 150, padT = 12, padB = 40;
    const plotW = width - padL - padR, plotH = o.height - padT - padB;
    const xmin = xs[0], xmax = xs[xs.length - 1];
    const X = (v) => padL + ((v - xmin) / (xmax - xmin)) * plotW;
    const Y = (v) => padT + plotH - v * plotH; // 0..1
    const svg = s("svg", { viewBox: `0 0 ${width} ${o.height}`, role: "img", "aria-label": o.aria || "Line chart" });
    for (let i = 0; i <= 4; i++) {
      const gy = Y(i / 4);
      svg.append(s("line", { x1: padL, x2: padL + plotW, y1: gy, y2: gy, stroke: i === 0 ? css("--baseline") : css("--grid") }));
      svg.append(s("text", { x: padL - 6, y: gy + 4, "text-anchor": "end", "font-size": 11, fill: css("--axis-muted"), text: o.yFmt(i / 4) }));
    }
    for (let v = Math.ceil(xmin); v <= xmax + 1e-9; v += narrow ? 1 : 0.5) {
      svg.append(s("text", { x: X(v), y: padT + plotH + 16, "text-anchor": "middle", "font-size": 11, fill: css("--axis-muted"), text: o.xFmt(v) }));
    }
    svg.append(s("text", { x: padL + plotW / 2, y: o.height - 4, "text-anchor": "middle", "font-size": 11.5, fill: css("--axis-muted"), text: narrow && o.xTitleShort ? o.xTitleShort : o.xTitle }));
    if (o.marker != null) {
      svg.append(s("line", { x1: X(o.marker), x2: X(o.marker), y1: padT, y2: padT + plotH, stroke: css("--text-primary"), "stroke-width": 1 }));
    }
    // end labels with simple collision avoidance
    const ends = series.map((se) => ({ se, y: Y(se.values[se.values.length - 1]) })).sort((a, b) => a.y - b.y);
    for (let i = 1; i < ends.length; i++) if (ends[i].y - ends[i - 1].y < 14) ends[i].y = ends[i - 1].y + 14;
    series.forEach((se) => {
      const d = se.values.map((v, i) => (i ? "L" : "M") + X(xs[i]).toFixed(1) + "," + Y(v).toFixed(1)).join("");
      svg.append(s("path", { d, fill: "none", stroke: se.color, "stroke-width": 2, "stroke-linejoin": "round", "stroke-linecap": "round" }));
      if (o.marker != null) {
        const idx = xs.findIndex((v) => Math.abs(v - o.marker) < 1e-9);
        if (idx >= 0) svg.append(s("circle", { cx: X(o.marker), cy: Y(se.values[idx]), r: 4.5, fill: se.color, stroke: css("--surface-1"), "stroke-width": 2 }));
      }
    });
    if (!narrow) ends.forEach(({ se, y }) => {
      const lx = padL + plotW + 8;
      const ly = Y(se.values[se.values.length - 1]);
      if (Math.abs(ly - y) > 2) svg.append(s("line", { x1: padL + plotW + 1, x2: lx - 2, y1: ly, y2: y, stroke: css("--grid") }));
      svg.append(s("line", { x1: lx, x2: lx + 10, y1: y, y2: y, stroke: se.color, "stroke-width": 2 }));
      svg.append(s("text", { x: lx + 14, y: y + 4, "font-size": 11.5, fill: css("--text-secondary"), text: se.name }));
    });
    // crosshair
    const cross = s("line", { x1: 0, x2: 0, y1: padT, y2: padT + plotH, stroke: css("--axis-muted"), "stroke-width": 1, visibility: "hidden" });
    svg.append(cross);
    const hit = s("rect", { x: padL, y: padT, width: plotW, height: plotH, fill: "transparent", tabindex: 0 });
    const at = (evt) => {
      const r = svg.getBoundingClientRect();
      const px = ((evt.clientX - r.left) / r.width) * width;
      const v = xmin + ((px - padL) / plotW) * (xmax - xmin);
      let idx = 0, best = Infinity;
      xs.forEach((xv, i) => { const dd = Math.abs(xv - v); if (dd < best) { best = dd; idx = i; } });
      return idx;
    };
    const show = (evt, idx) => {
      cross.setAttribute("x1", X(xs[idx])); cross.setAttribute("x2", X(xs[idx])); cross.setAttribute("visibility", "visible");
      showTip(evt, { title: o.tipTitle ? o.tipTitle(xs[idx]) : o.xFmt(xs[idx]), rows: series.map((se) => ({ color: se.color, value: o.yFmt(se.values[idx], true), label: se.name })) });
    };
    hit.addEventListener("pointermove", (e) => show(e, at(e)));
    hit.addEventListener("pointerleave", () => { cross.setAttribute("visibility", "hidden"); hideTip(); });
    hit.addEventListener("focus", (e) => show(e, Math.max(0, xs.findIndex((v) => o.marker != null && Math.abs(v - o.marker) < 1e-9))));
    hit.addEventListener("blur", () => { cross.setAttribute("visibility", "hidden"); hideTip(); });
    if (o.onPick) hit.addEventListener("click", (e) => o.onPick(xs[at(e)]));
    svg.append(hit);
    container.append(svg);
  }

  function legend(container, items, type = "rect") {
    clear(container);
    items.forEach((it) => container.append(el("span", null, el("i", { class: type === "line" ? "line" : "", style: "background:" + it.color }), document.createTextNode(it.name))));
  }

  // ------------------------------------------------------------------ tables & CSV
  const tableData = {};
  function table(id, headers, rows, hlIndex) {
    tableData[id] = { headers, rows };
    const host = clear($(id));
    const t = el("table", { class: "data" });
    const thead = el("thead", null, el("tr", null, ...headers.map((h) => el("th", { text: h }))));
    const tbody = el("tbody");
    rows.forEach((r, i) => tbody.append(el("tr", { class: i === hlIndex ? "hl" : "" }, ...r.map((c) => el("td", { text: c.display != null ? c.display : String(c) })))));
    t.append(thead, tbody);
    host.append(t);
  }
  function toCSV(id) {
    const { headers, rows } = tableData[id];
    const q = (v) => { const str = v == null ? "" : String(v); return /[",\n]/.test(str) ? '"' + str.replace(/"/g, '""') + '"' : str; };
    return [headers.map(q).join(",")].concat(rows.map((r) => r.map((c) => q(c.raw != null ? c.raw : c.display != null ? c.display : c)).join(","))).join("\n");
  }
  const cell = (raw, display) => ({ raw: raw == null ? "" : typeof raw === "number" ? +raw.toFixed(6) : raw, display: display != null ? display : raw == null ? "–" : String(raw) });
  function toast(msg) { const t = $("toast"); t.textContent = msg; t.classList.add("on"); setTimeout(() => t.classList.remove("on"), 1800); }
  document.addEventListener("click", (e) => {
    const c = e.target.closest("[data-copy]");
    if (c) {
      const txt = toCSV(c.dataset.copy);
      (navigator.clipboard ? navigator.clipboard.writeText(txt) : Promise.reject()).then(() => toast(window.L ? window.L("Table copied as CSV", "Jedwali limenakiliwa kama CSV") : "Table copied as CSV"), () => toast(window.L ? window.L("Copy not available here", "Kunakili hakuwezekani hapa") : "Copy not available here"));
    }
    const d = e.target.closest("[data-download]");
    if (d) {
      try {
        const blob = new Blob([toCSV(d.dataset.download)], { type: "text/csv" });
        const a = el("a", { href: URL.createObjectURL(blob), download: "tanzania-hbs-" + d.dataset.download + ".csv" });
        document.body.append(a); a.click(); a.remove();
      } catch (err) { toast(window.L ? window.L("Download not available here", "Kupakua hakuwezekani hapa") : "Download not available here"); }
    }
  });
  let embedded = false;
  try { embedded = window.self !== window.top; } catch (e) { embedded = true; }
  if (embedded) document.querySelectorAll(".dl-only").forEach((b) => b.remove());

  window.Viz = { nf0, nf1, tzs, tzsShort, pct, pctAxis, num1, num2, css, SERIES, el, s, $, clear, textW, showTip, moveTip, hideTip, bindTip,
    niceScale, tickText, hbar, stacked, columns, lines, legend, table, cell, toast, embedded };
})();
