"""Main cooking fuel shares from the IASES 2021/22 public-use file (trend point only).

Usage: python3 -I iases_main_fuel.py <TZA-NBS-IASES_HH-v01.dta> <out.json>
"""
import json
import sys

import pandas as pd

P, OUT = sys.argv[1], sys.argv[2]
d = pd.read_stata(P, columns=["WEIGHT", "UrbRur", "B14"], convert_categoricals=False)
B14_MAP = {1: "Electricity", 2: "Electricity", 3: "Electricity", 4: "LPG", 5: "Biogas", 7: "Kerosene / paraffin", 8: "Charcoal",
           9: "Charcoal", 10: "Firewood"}
d["main_fuel"] = d.B14.map(B14_MAP)
main_fuel = {}
for ar, sel in [("national", d.index == d.index), ("Rural", d.UrbRur == 2), ("Urban", d.UrbRur == 1)]:
    dd = d[sel & d.main_fuel.notna()]
    s = dd.groupby("main_fuel").WEIGHT.sum() / dd.WEIGHT.sum()
    main_fuel[ar] = {k: float(v) for k, v in s.items()}
json.dump({"desc": {"n": int(len(d))}, "main_fuel": main_fuel}, open(OUT, "w"), indent=1)
print(main_fuel["national"])
