"""Survey-weighted logit with cluster-robust standard errors and average marginal effects (AMEs).

Point estimates equal Stata's `logit y x [pw=w], vce(cluster c)`; AMEs equal `margins, dydx(*)` (discrete change
for 0/1 dummies, derivative for continuous variables), with delta-method standard errors.
"""
import numpy as np
import pandas as pd
from math import erf, sqrt


def _sig(z):
    return 1.0 / (1.0 + np.exp(-z))


def fit(y, X, w, cluster, max_iter=100, tol=1e-10):
    y = np.asarray(y, float)
    X = np.asarray(X, float)
    w = np.asarray(w, float)
    b = np.zeros(X.shape[1])
    for _ in range(max_iter):
        p = _sig(X @ b)
        W = w * p * (1 - p)
        H = X.T @ (X * W[:, None])
        g = X.T @ (w * (y - p))
        step = np.linalg.solve(H, g)
        b += step
        if np.max(np.abs(step)) < tol:
            break
    p = _sig(X @ b)
    A_inv = np.linalg.inv(X.T @ (X * (w * p * (1 - p))[:, None]))
    scores = X * (w * (y - p))[:, None]
    S = pd.DataFrame(scores).groupby(np.asarray(cluster)).sum().to_numpy()
    G = S.shape[0]
    n, k = X.shape
    B = S.T @ S * (G / (G - 1)) * ((n - 1) / (n - k))
    V = A_inv @ B @ A_inv
    return b, V


def pnorm2(z):
    return 2 * (1 - 0.5 * (1 + erf(abs(z) / sqrt(2))))


def ames(b, V, X, w, names, dummies):
    """Average marginal effects. dummies: set of column names that are 0/1 indicators (discrete change)."""
    X = np.asarray(X, float)
    w = np.asarray(w, float) / np.sum(w)

    def ame_vec(beta):
        out = []
        for j, nm in enumerate(names):
            if nm == "const":
                out.append(np.nan)
                continue
            if nm in dummies:
                X1, X0 = X.copy(), X.copy()
                X1[:, j], X0[:, j] = 1, 0
                out.append(np.sum(w * (_sig(X1 @ beta) - _sig(X0 @ beta))))
            else:
                p = _sig(X @ beta)
                out.append(np.sum(w * p * (1 - p)) * beta[j])
        return np.array(out)

    m = ame_vec(b)
    eps = 1e-6
    J = np.zeros((len(b), len(b)))
    for k in range(len(b)):
        bp = b.copy()
        bp[k] += eps
        J[:, k] = (ame_vec(bp) - m) / eps
    J = np.nan_to_num(J)
    se = np.sqrt(np.clip(np.diag(J @ V @ J.T), 0, None))
    rows = []
    for j, nm in enumerate(names):
        if nm == "const":
            continue
        z = m[j] / se[j] if se[j] > 0 else np.nan
        rows.append({"term": nm, "ame": float(m[j]), "se": float(se[j]), "p": float(pnorm2(z)) if np.isfinite(z) else None,
                     "coef": float(b[j]), "coef_se": float(np.sqrt(V[j, j]))})
    return rows
