"""Build the data file for the Tanzania clean cooking site.

Usage: python3 -I process_cc.py <hecs_dir> <hbs_dir> <iases_json> <out_json>
  hecs_dir  : unzipped 2023 Household Energy Consumption Survey Stata files
  hbs_dir   : unzipped HBS 2017-18 Stata files (for the 2017-18 trend point)
  iases_json: output of iases_models.py (IASES 2021/22 results)
All HECS shares are weighted by the household weight (hhldWT), so they read as "% of households".
"""
import json
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, sys.argv[0].rsplit("/", 1)[0])
import wlogit  # noqa: E402

HECS, HBS, IASES_JSON, OUT = sys.argv[1:5]

# ------------------------------------------------------------------ HECS: cooking section
w = pd.read_stata(f"{HECS}/weight.dta")
c = pd.read_stata(f"{HECS}/sec_3_cooking.dta", convert_categoricals=False)
with pd.io.stata.StataReader(f"{HECS}/sec_3_cooking.dta") as r:
    REG = {int(k): ("Dar es Salaam" if v == "Dar Es Salaam" else v) for k, v in r.value_labels()["region"].items()}
c = c.merge(w, left_on="full_ea_code", right_on="EA_ID", how="left")
assert c.hhldWT.notna().all()
c["W"] = c.hhldWT

yes = lambda s: (s == 1)
# fuel: (use flag column, activities-per-week column)
FUELS = {
    "Firewood": ("s3q10", "s3q102"),
    "Charcoal": ("s3q11", "s3q112"),
    "LPG": ("s3q4", "s3q41"),
    "Electricity": ("s3q3", "s3q31"),
    "Biogas": ("s3q8", "s3q81"),          # the questionnaire repeats the 'natural gas' label; NBS tabulates s3q8 as biogas
    "Natural gas": ("s3q7", "s3q71"),
    "Bioethanol": ("s3q9", "s3q91"),
    "Kerosene / paraffin": (None, None),
    "Crop residues & other": ("s3q12", "s3q122"),
}
CLEAN = ["LPG", "Electricity", "Biogas", "Natural gas", "Bioethanol"]
SOLID = ["Firewood", "Charcoal", "Crop residues & other"]
use, act = {}, {}
for f, (u, a) in FUELS.items():
    if f == "Kerosene / paraffin":
        use[f] = yes(c.s3q5) | yes(c.s3q6)
        act[f] = np.where(use[f], c[["s3q51", "s3q61"]].sum(axis=1, min_count=1).fillna(1), 0)
    else:
        use[f] = yes(c[u])
        act[f] = np.where(use[f], c[a].fillna(1).clip(lower=1), 0)
U = pd.DataFrame(use).astype(float)
A = pd.DataFrame(act).astype(float)
FUEL_ORDER = list(FUELS)

# primary fuel = fuel used for the most cooking events per week; ties go to the more polluting fuel (conservative)
POLLUTION_RANK = {"Crop residues & other": 0, "Firewood": 1, "Charcoal": 2, "Kerosene / paraffin": 3, "Bioethanol": 4,
                  "Biogas": 5, "Natural gas": 6, "LPG": 7, "Electricity": 8}
cols_by_rank = sorted(FUEL_ORDER, key=lambda f: POLLUTION_RANK[f])
Ar = A[cols_by_rank]
primary = Ar.idxmax(axis=1).where(Ar.max(axis=1) > 0, "None reported")
maxv = Ar.max(axis=1)
n_ties = int(((Ar.eq(maxv, axis=0)) & (Ar > 0)).sum(axis=1).gt(1).sum())
c["primary"] = primary
c["any_clean"] = U[CLEAN].max(axis=1)
c["any_solid"] = U[SOLID + ["Kerosene / paraffin"]].max(axis=1)
c["primary_clean"] = primary.isin(CLEAN).astype(float)
c["exclusive_clean"] = ((c.any_clean == 1) & (c.any_solid == 0)).astype(float)
c["stacking"] = ((c.any_clean == 1) & (c.any_solid == 1)).astype(float)
c["solid_only"] = ((c.any_clean == 0) & (c.any_solid == 1)).astype(float)
c["n_fuels"] = U.sum(axis=1)
c["indoor"] = yes(c.s3).astype(float)
c["events_total"] = A.sum(axis=1)
c["events_clean"] = A[CLEAN].sum(axis=1)
# improved stoves
FW_STOVE = {1: "Three-stone fire", 2: "Round mud stove", 3: "Improved cookstove", 4: "Rocket stove", 5: "Burned mud/clay stove",
            6: "Lorena rocket stove", 7: "Metal rocket stove", 9: "Mozambique metal rocket stove"}
FW_IMPROVED = {3, 4, 6, 7, 9}
CH_STOVE = {1: "Traditional charcoal stove", 2: "Traditional raised charcoal stove", 3: "Old-generation charcoal ICS", 4: "Ceramic-lined charcoal ICS"}
CH_IMPROVED = {3, 4}
c["fw_user"] = U.Firewood
c["ch_user"] = U.Charcoal
c["fw_improved"] = np.where(U.Firewood == 1, c.s3q101.isin(FW_IMPROVED).astype(float), np.nan)
c["ch_improved"] = np.where(U.Charcoal == 1, c.s3q111.isin(CH_IMPROVED).astype(float), np.nan)
c["three_stone"] = (c.s3q101 == 1).astype(float)
# "clean or improved" for the primary fuel: clean primary, or primary solid fuel burned in an improved stove
c["primary_clean_or_ics"] = (c.primary_clean.astype(bool)
                             | ((c.primary == "Firewood") & c.s3q101.isin(FW_IMPROVED))
                             | ((c.primary == "Charcoal") & c.s3q111.isin(CH_IMPROVED))).astype(float)

# ------------------------------------------------------------------ HECS: household head, electricity
a = pd.read_stata(f"{HECS}/sec_a_households_demographic.dta", columns=["hhid", "r1__id", "hhsize", "a2", "a3", "age", "a6_1"], convert_categoricals=False)
b = pd.read_stata(f"{HECS}/sec_b_education.dta", columns=["hhid", "r1__id", "b2", "b4"], convert_categoricals=False)
head = a[a.a3 == 1].drop_duplicates("hhid").merge(b, on=["hhid", "r1__id"], how="left")
hs = a.groupby("hhid").hhsize.max()
e = head.b4
head["educ"] = np.where(e.isin([34, 41, 42, 43, 44, 45]), "Tertiary", np.where(e.between(21, 33), "Secondary",
                np.where(e.between(11, 20), "Primary", "None / pre-primary")))
o = head.a6_1
head["occ"] = np.select([o.isin([1, 2, 3, 4, 15, 17, 18]), o.isin([5, 6]), o.isin([7, 8, 9, 16, 19])],
                        ["Agriculture", "Formal employment", "Business / self-employed"], "Not working")
head.loc[o.isna(), "occ"] = np.nan
head["male"] = (head.a2 == 1).astype(float)
head = head.set_index("hhid")
c = c.join(head[["educ", "occ", "male", "age"]], on="hhid")
c["hhsize"] = c.hhid.map(hs)
el = pd.read_stata(f"{HECS}/sec_2_electricity.dta", columns=["hhid", "s2q2", "s2q211", "s2q212", "s2q213", "s2q224"], convert_categoricals=False).drop_duplicates("hhid").set_index("hhid")
c = c.join(el, on="hhid")
c["grid"] = (c.s2q211 == 1).astype(float)
c["any_elec"] = (c.s2q2 == 1).astype(float)
c["solar_only"] = ((c.s2q213 == 1) & (c.s2q211 != 1) & (c.s2q212 != 1)).astype(float)
c["urban"] = (c.rural_urban == 2).astype(float)
c["hhsize_band"] = pd.cut(c.hhsize, [0, 2, 4, 6, 100], labels=["1–2 people", "3–4 people", "5–6 people", "7+ people"]).astype(str)
c["area"] = np.where(c.urban == 1, "Urban", "Rural")
c["power"] = np.select([c.grid == 1, c.any_elec == 1], ["Grid (TANESCO)", "Solar or other off-grid"], "No electricity")

# ------------------------------------------------------------------ HECS: fuel spending & prices (section 7)
q = pd.read_stata(f"{HECS}/sec_7_quantities_used.dta", columns=["hhid", "s7q11", "s7q11a", "s7q12a", "s7q13", "lpgprice", "s7q8", "s7q82",
                                                                 "s7q9", "s7q91", "s7q91a", "s7q92"], convert_categoricals=False).drop_duplicates("hhid").set_index("hhid")
c = c.join(q, on="hhid")
c["lpg_month"] = np.where(c.s7q13 > 0, c.s7q13 / np.where(c.s7q11a == 2, 12, 1), np.nan)
c["lpg_refill"] = c.lpgprice
c["lpg_size"] = c.s7q12a
c["ch_month"] = np.where(c.s7q92 > 0, c.s7q92 / np.where(c.s7q91a == 2, 12, 1), np.nan)
c["fw_month"] = np.where(c.s7q82 > 0, c.s7q82, np.nan)
c["buys_fw"] = np.where(U.Firewood == 1, (c.s7q8 == 1).astype(float), np.nan)
c["buys_ch"] = np.where(U.Charcoal == 1, (c.s7q9 == 1).astype(float), np.nan)
for v in ["lpg_month", "ch_month", "fw_month"]:  # trim implausible extremes (top 1% of reported monthly spend)
    hi = c[v].quantile(0.99)
    c.loc[c[v] > hi, v] = np.nan


def wmean(x, wt):
    m = x.notna() & wt.notna()
    return float(np.average(x[m], weights=wt[m])) if m.sum() else None


def wmedian(x, wt):
    m = x.notna() & wt.notna()
    if m.sum() < 30:
        return None
    xs, ws = x[m].to_numpy(), wt[m].to_numpy()
    o = np.argsort(xs)
    cw = np.cumsum(ws[o])
    return float(xs[o][np.searchsorted(cw, cw[-1] / 2)])


def summarise(d):
    W = d.W
    out = {"n": int(len(d)), "households": float(W.sum())}
    out["use"] = {f: wmean(U.loc[d.index, f], W) for f in FUEL_ORDER}
    pr = d.groupby("primary").W.sum() / W.sum()
    out["primary"] = {f: float(pr.get(f, 0.0)) for f in FUEL_ORDER + ["None reported"]}
    for k in ["primary_clean", "any_clean", "exclusive_clean", "stacking", "solid_only", "indoor", "primary_clean_or_ics", "three_stone", "grid", "any_elec"]:
        out[k] = wmean(d[k], W)
    out["events_clean_share"] = float((d.events_clean * W).sum() / (d.events_total * W).sum())
    out["n_fuels_mean"] = wmean(d.n_fuels.where(d.n_fuels > 0), W)
    out["n_fuels_dist"] = {str(k): float(W[d.n_fuels.clip(upper=3) == k].sum() / W.sum()) for k in [1, 2, 3]}
    out["fw_improved"] = wmean(d.fw_improved, W)
    out["ch_improved"] = wmean(d.ch_improved, W)
    fw = d[U.loc[d.index, "Firewood"] == 1]
    ch = d[U.loc[d.index, "Charcoal"] == 1]
    out["fw_stoves"] = {FW_STOVE[k]: float(fw.W[fw.s3q101 == k].sum() / fw.W.sum()) if len(fw) else None for k in FW_STOVE}
    out["ch_stoves"] = {CH_STOVE[k]: float(ch.W[ch.s3q111 == k].sum() / ch.W.sum()) if len(ch) else None for k in CH_STOVE}
    out["cost"] = {
        "lpg_refill_6": wmedian(d.lpg_refill.where(d.lpg_size == 6), W), "lpg_refill_15": wmedian(d.lpg_refill.where(d.lpg_size == 15), W),
        "lpg_month": wmedian(d.lpg_month, W), "ch_month": wmedian(d.ch_month, W), "fw_month": wmedian(d.fw_month, W),
        "buys_fw": wmean(d.buys_fw, W), "buys_ch": wmean(d.buys_ch, W),
        "n_lpg": int(d.lpg_month.notna().sum()), "n_ch": int(d.ch_month.notna().sum()), "n_fw": int(d.fw_month.notna().sum()),
        "lpg_6_share": wmean((d.lpg_size == 6).astype(float).where(d.lpg_size.notna()), W),
    }
    return out


views = {"national": {"label": "Mainland Tanzania", **summarise(c)}}
views["area_rural"] = {"label": "Rural", **summarise(c[c.urban == 0])}
views["area_urban"] = {"label": "Urban", **summarise(c[c.urban == 1])}
for code, name in sorted(REG.items(), key=lambda kv: kv[1]):
    views[f"reg_{code}"] = {"label": name, **summarise(c[c.region == code])}

# ------------------------------------------------------------------ drivers (HECS 2023)
def gradient(col, order):
    res = []
    for lv in order:
        d = c[c[col] == lv]
        if len(d) == 0:
            continue
        res.append({"label": lv, "n": int(len(d)), "share": float(d.W.sum() / c.loc[c[col].notna(), "W"].sum()),
                    "primary_clean": wmean(d.primary_clean, d.W), "any_clean": wmean(d.any_clean, d.W),
                    "lpg": wmean(U.loc[d.index, "LPG"], d.W), "electric": wmean(U.loc[d.index, "Electricity"], d.W),
                    "primary_clean_or_ics": wmean(d.primary_clean_or_ics, d.W)})
    return res

drivers = {
    "power": gradient("power", ["No electricity", "Solar or other off-grid", "Grid (TANESCO)"]),
    "educ": gradient("educ", ["None / pre-primary", "Primary", "Secondary", "Tertiary"]),
    "area": gradient("area", ["Rural", "Urban"]),
    "occ": gradient("occ", ["Agriculture", "Not working", "Business / self-employed", "Formal employment"]),
    "sex": gradient("male", [0.0, 1.0]),
    "hhsize": gradient("hhsize_band", ["1–2 people", "3–4 people", "5–6 people", "7+ people"]),
}
for r_ in drivers["sex"]:
    r_["label"] = "Male-headed" if r_["label"] == 1.0 else "Female-headed"
# grid x area interaction: does the grid matter in rural areas too?
drivers["grid_by_area"] = []
for ar in ["Rural", "Urban"]:
    for g, gl in [(0.0, "Not on grid"), (1.0, "On grid")]:
        d = c[(c.area == ar) & (c.grid == g)]
        drivers["grid_by_area"].append({"area": ar, "grid": gl, "n": int(len(d)), "primary_clean": wmean(d.primary_clean, d.W), "lpg": wmean(U.loc[d.index, "LPG"], d.W)})

# weighted logit: clean primary fuel, 2023
md = c.dropna(subset=["educ", "occ", "male", "age", "hhsize"]).copy()
X = pd.DataFrame({"const": 1.0}, index=md.index)
X["Grid connection (TANESCO)"] = md.grid
X["Off-grid electricity only"] = ((md.any_elec == 1) & (md.grid == 0)).astype(float)
X["Urban residence"] = md.urban
for lv in ["Primary", "Secondary", "Tertiary"]:
    X[f"Head education: {lv}"] = (md.educ == lv).astype(float)
for lv in ["Agriculture", "Business / self-employed", "Not working"]:
    X[f"Head occupation: {lv}"] = (md.occ == lv).astype(float)
X["Male-headed household"] = md.male
X["Age of head (per year)"] = md.age
X["Household size (per person)"] = md.hhsize
dummies = {k for k in X.columns if k not in ("const", "Age of head (per year)", "Household size (per person)")}
models23 = {}
for y in ["primary_clean", "any_clean"]:
    bcoef, V = wlogit.fit(md[y], X, md.W, md.full_ea_code)
    models23[y] = {"n": int(len(md)), "rows": wlogit.ames(bcoef, V, X, md.W, list(X.columns), dummies)}

# ------------------------------------------------------------------ trend: main cooking fuel 2017-18 (HBS) / 2021-22 (IASES) / 2023 (HECS)
hbs = pd.read_stata(f"{HBS}/HBS_2017-18 Consumption Aggregate and Poverty Analysis Variables.dta", columns=["weight", "S12_08", "LOC"], convert_categoricals=False)
HBS_MAP = {1: "Electricity", 2: "Crop residues & other", 3: "Electricity", 4: "LPG", 5: "Biogas", 6: "Kerosene / paraffin", 7: "Charcoal",
           8: "Charcoal", 9: "Firewood", 10: "Firewood", 11: "Crop residues & other", 94: "Crop residues & other"}  # solar (2) reported for cooking is implausible: grouped with other
hbs["fuel"] = hbs.S12_08.map(HBS_MAP)
iases = json.load(open(IASES_JSON))


def mainfuel_shares(df, wcol, fcol):
    d = df[df[fcol].notna()]
    s = d.groupby(fcol)[wcol].sum() / d[wcol].sum()
    return {k: float(v) for k, v in s.items()}

trend = {"HBS 2017-18": {}, "IASES 2021-22": iases.get("main_fuel", {}), "HECS 2023": {}}
for ar, sel in [("national", hbs.index == hbs.index), ("Rural", hbs.LOC == 1), ("Urban", hbs.LOC == 2)]:
    trend["HBS 2017-18"][ar] = mainfuel_shares(hbs[sel], "weight", "fuel")
cp = c[c.primary != "None reported"]
for ar, sel in [("national", cp.index == cp.index), ("Rural", cp.urban == 0), ("Urban", cp.urban == 1)]:
    trend["HECS 2023"][ar] = mainfuel_shares(cp[sel], "W", "primary")

data = {
    "meta": {
        "fuels": FUEL_ORDER, "clean_fuels": CLEAN, "n_households": int(len(c)), "weighted_households": float(c.W.sum()),
        "ties": n_ties, "regions": [views[k]["label"] for k in views if k.startswith("reg_")],
    },
    "views": views, "drivers": drivers, "models2023": models23, "trend": trend, "iases": iases,
}


def clean(o):
    if isinstance(o, dict):
        return {str(k): clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [clean(v) for v in o]
    if isinstance(o, (float, np.floating)):
        return None if not np.isfinite(o) else round(float(o), 6)
    if isinstance(o, np.integer):
        return int(o)
    return o

json.dump(clean(data), open(OUT, "w"), separators=(",", ":"))
n = views["national"]
print("ties:", n_ties, "| households:", len(c), "| weighted (M):", round(c.W.sum() / 1e6, 2))
print("use:", {k: round(v * 100, 1) for k, v in n["use"].items()})
print("primary:", {k: round(v * 100, 1) for k, v in n["primary"].items()})
for k in ["primary_clean", "any_clean", "exclusive_clean", "stacking", "solid_only", "indoor", "primary_clean_or_ics", "events_clean_share", "grid", "any_elec", "fw_improved", "ch_improved", "three_stone"]:
    print(f"  {k}: {n[k]*100:.1f}")
print("rural/urban primary_clean:", views['area_rural']['primary_clean'], views['area_urban']['primary_clean'])
print("cost:", n["cost"])
print("ch_stoves:", n["ch_stoves"])
for k, v in drivers.items():
    print(k, [(r_.get("label", r_.get("area")), r_.get("grid", ""), round(r_["primary_clean"] * 100, 1)) for r_ in v])
for y, m in models23.items():
    print(y, m["n"])
    for r_ in m["rows"]:
        print(f"   {r_['term']:38s} {r_['ame']*100:7.2f} pp (se {r_['se']*100:.2f}) p={r_['p']:.3f}")
print("trend HBS:", {k: round(v * 100, 1) for k, v in trend["HBS 2017-18"]["national"].items()})
print("trend HECS:", {k: round(v * 100, 1) for k, v in trend["HECS 2023"]["national"].items()})
