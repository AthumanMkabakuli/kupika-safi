# Kupika Safi: Tanzania Clean Cooking Observatory

Interactive dashboards on household cooking energy in Mainland Tanzania, by **A. Ahmed Abdallah**, Energy Economist and Assistant Lecturer, University of Dar es Salaam.

Data: NBS 2023 Household Energy Consumption Survey (HECS), Impact of Access to Sustainable Energy Survey (IASES) 2021/22, Household Budget Survey 2017-18, and the Ministry of Energy's National Clean Cooking Strategy 2024–2034.

## Deploy to Netlify
Drag this folder (the one containing `index.html`) onto **Sites → Add new site → Deploy manually** at app.netlify.com. Then rename the site under **Site configuration → Change site name** (for example `tanzania-clean-cooking`).
There is no build step; `netlify.toml` publishes the folder as is.

## Files
| Path | What it is |
|---|---|
| `index.html` | The page, with hash routes `#home`, `#fuels`, `#stoves`, `#cost`, `#drivers`, `#research`, `#progress`, `#about` |
| `css/site.css` | Styles, with light and dark themes |
| `js/viz.js` | Chart toolkit in plain SVG, with no dependencies |
| `js/app.js` | Page logic |
| `data/cc.js`, `data/cc.json` | All computed estimates |
| `analysis/` | Python scripts that rebuild the data from the NBS Stata files |

## Rebuilding the data
```bash
pip install pandas numpy
python3 analysis/iases_main_fuel.py "IASES/TZA-NBS-IASES_HH-v01.dta" iases.json
python3 analysis/process_cc.py "<HECS Stata folder>" "<HBS 2017-18 Stata folder>" iases.json data/cc.json
( printf 'window.CC = '; cat data/cc.json; printf ';\n' ) > data/cc.js
```
The NBS microdata is not included; it is available from microdata.nbs.go.tz.
